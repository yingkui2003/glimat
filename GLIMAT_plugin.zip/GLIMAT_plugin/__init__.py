"""
/*******************************************************************************
* GLIMAT (Glacier Lineation and Ice Margin Analysis Toolkit) is free software: *
* You can redistribute it and/or modify it under the terms of the              *
* GNU General Public License as published by the Free Software Foundation,     *
* either version 3 of the License, or (at your option) any later version.      *
*                                                                              *
* GLIMAT is distributed in the hope that it will be useful,                    *
* but WITHOUT ANY WARRANTY; without even the implied warranty                  *
* of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                      *
* See the GNU General Public License for more details.                         *
*                                                                              *
* You should have received a copy of the GNU General Public License            *
* along with GLIMAT. If not, see <https://www.gnu.org/licenses/>.              *
*                                                                              *
* Author: Yingkui Li                                                           *
* Department of Geography & Sustainability                                     *
* University of Tennessee, Knoxville, TN 37996                                 * 
* Email: yli32@utk.edu                                                         *
* Start date: 06/01/2026                                                       *
* Finalized date: 06/01/2026                                                   *
* Copyright(C): 2026 Yingkui Li                                                * 
*                                                                              *
* Version: 1.0.0                                                               *
*******************************************************************************/
"""

# Import the main plugin class
from .glacier_analysis_toolkit import GlacierAnalysisToolkit


def classFactory(iface):
    """Create the plugin instance"""
    return GlacierAnalysisToolkit(iface)