# resources.py
# Manually created resources file for Glacier Analysis Toolkit

def qInitResources():
    """Initialize resources (manual version)"""
    pass

def qCleanupResources():
    """Cleanup resources (manual version)"""
    pass

# For compatibility with pyrcc5 generated files
import os
from qgis.PyQt.QtCore import QDir, QFileInfo

# Register the icon path
plugin_dir = os.path.dirname(__file__)
icon_path = os.path.join(plugin_dir, 'icons', 'icon.png')