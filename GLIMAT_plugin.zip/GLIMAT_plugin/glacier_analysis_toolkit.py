"""
/*********************************************************************************
* GLIMAT - Main Plugin Class                                                     *
* ===================================================                            *
*                                                                                *
* This file is part of GLIMAT Plugin.                                            *
*                                                                                *
* Author: Yingkui Li                                                             *
* Department of Geography & Sustainability                                       *
* University of Tennessee, Knoxville, TN 37996                                   * 
* Email: yli32@utk.edu                                                           *
* Start date: 06/01/2026                                                         *
* Finalized date: 09/17/2026                                                     *
* Copyright(C): 2026 Yingkui Li                                                  * 
*                                                                                *
* Version: 1.0.0                                                                 *
*********************************************************************************/
"""
import os
from pathlib import Path

from qgis.gui import QgisInterface
from qgis.PyQt.QtCore import QCoreApplication, QTranslator
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

from .glacier_analysis_toolkit_dialog import GlacierAnalysisToolkitDialog


class GlacierAnalysisToolkit:
    """QGIS plugin implementation for the GLIMAT Toolkit."""

    def __init__(self, iface: QgisInterface):
        self.iface = iface
        self.plugin_dir = str(Path(__file__).parent)

        # Translations (activate by shipping a .qm file in an 'i18n' folder).
        # self.locale = QSettings().value('locale/userLocale')[0:2]
        # locale_path = str(Path(self.plugin_dir) / 'i18n'
        #                   / f'GLIMAT_{self.locale}.qm')
        # if os.path.exists(locale_path):
        #     self.translator = QTranslator()
        #     self.translator.load(locale_path)
        #     QCoreApplication.installTranslator(self.translator)

        self.actions = []
        self.menu = 'GLIMAT Toolkit'
        self.toolbar = self.iface.addToolBar('GLIMAT Toolkit')
        self.toolbar.setObjectName('GLIMAT_Toolkit')

        # Hold a reference to the dialog so Qt does not garbage-collect it.
        self.dialog = None

    def tr(self, message):
        """Return the translation for the given string."""
        return QCoreApplication.translate('GLIMAT_Toolkit', message)

    def add_action(self, icon_path, text, callback, enabled_flag=True,
                   add_to_menu=True, add_to_toolbar=True, status_tip=None,
                   whats_this=None, parent=None):
        """Register a QAction on the plugin toolbar and menu."""
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip:
            action.setStatusTip(status_tip)
        if whats_this:
            action.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def initGui(self):
        """Create the menu entries and toolbar icons."""
        icon_path = str(Path(self.plugin_dir) / 'icons' / 'icon.png')
        self.add_action(
            icon_path,
            text=self.tr('GLIMAT Toolkit'),
            callback=self.run,
            parent=self.iface.mainWindow(),
        )

    def unload(self):
        """Remove the plugin from QGIS."""
        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)
        self.actions.clear()
        self.toolbar = None

    def run(self):
        """Open the plugin dialog (reuse if it is already visible)."""
        if self.dialog is None:
            self.dialog = GlacierAnalysisToolkitDialog(self.iface.mainWindow())
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()        