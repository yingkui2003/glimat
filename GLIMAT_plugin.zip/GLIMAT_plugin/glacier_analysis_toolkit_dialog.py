"""
/*********************************************************************************
# GLIMAT Dialog GUI with Console Output and Variable Selection                   *
*                                                                                *
* This file is part of GLIMAT Plugin.                                            *
*                                                                                *
* Author: Yingkui Li                                                             *
* Department of Geography & Sustainability                                       *
* University of Tennessee, Knoxville, TN 37996                                   *
* Email: yli32@utk.edu                                                           *
* Start date: 06/05/2026                                                         *
* Finalized date: 09/17/2026                                                     *
* Copyright(C): 2026 Yingkui Li                                                  *
*                                                                                *
* Version: 1.0.0                                                                 *
*********************************************************************************/
"""

import os
import sys
from pathlib import Path
from datetime import datetime
import numpy as np
import time

from qgis.PyQt.QtCore import Qt, pyqtSignal, QThread, QMetaObject, Q_ARG
from qgis.PyQt.QtGui import QFont, QTextCursor
from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QTabWidget,
                                  QGroupBox, QLabel, QLineEdit, QComboBox,
                                  QPushButton, QSpinBox, QDoubleSpinBox,
                                  QCheckBox, QFileDialog, QProgressBar, QTextEdit,
                                  QPlainTextEdit, QWidget, QFormLayout, QMessageBox,
                                  QSplitter, QApplication)

from qgis.core import QgsMessageLog, Qgis

import xarray as xr


def fix_time_coordinates(ds):
    """Fix corrupted time coordinates in Model Output NetCDF file"""
    print("\n" + "="*60)
    print("FIXING TIME COORDINATES")
    print("="*60)

    print(f"Original time range: {ds.time.values[0]} to {ds.time.values[-1]}")

    n_times = len(ds.time)
    time_years = np.arange(n_times)
    ds = ds.assign_coords(time=time_years)
    ds.time.attrs['long_name'] = 'time'
    ds.time.attrs['units'] = 'years since simulation start'

    print(f"Fixed time range: {ds.time.values[0]} to {ds.time.values[-1]}")
    print(f"Number of time steps: {n_times}")

    return ds


class AnalysisWorker(QThread):
    """Worker thread for running the model"""
    output_signal = pyqtSignal(str, str)  # (tag, message)
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(bool, str)

    def __init__(self, analysis_type, params):
        super().__init__()
        self.analysis_type = analysis_type
        self.params = params
        self._is_cancelled = False
        self._current_analyzer = None
        self.start_time = None

        # Rate limiting for console output
        self.output_buffer = []
        self.last_update_time = 0

        self._buffer_lock = None  # Will initialize in run()
        self._console_callback = None

    def emit_output(self, tag, message):
        """Emit output with throttling to prevent GUI freezing"""
        import time
        current_time = time.time()

        # Buffer output if too frequent (more than 50 messages per second)
        if current_time - self.last_update_time < 0.02:  # 20ms throttle
            self.output_buffer.append((tag, message))
            if len(self.output_buffer) > 100:  # Limit buffer size
                self.flush_buffer()
            return

        # Flush buffer first
        self.flush_buffer()

        # Emit current line
        self.output_signal.emit(tag, message)
        self.last_update_time = current_time

    def flush_buffer(self):
        """Flush buffered output"""
        if self.output_buffer:
            # Combine multiple lines if too many
            if len(self.output_buffer) > 20:
                combined = f"[... {len(self.output_buffer)} lines omitted ...]"
                self.output_signal.emit("info", combined)
            else:
                for tag, message in self.output_buffer:
                    self.output_signal.emit(tag, message)
            self.output_buffer.clear()

    def set_console_callback(self, callback):
        """Set console callback (alternative to signal)"""
        self._console_callback = callback

    def update_progress_callback(self, percent, message):
        """Callback function for progress updates from analyzers"""
        if self._is_cancelled:
            return
        self.progress.emit(percent, message)
        self.output_signal.emit("info", f"  Progress: {percent}% - {message}")

    def cancel(self):
        """Request cancellation of the analysis"""
        self._is_cancelled = True
        self.output_signal.emit("info", "\n" + "="*50)
        self.output_signal.emit("info", "CANCELLATION REQUESTED - Stopping analysis...")
        self.output_signal.emit("info", "="*50)

        # Try to stop the analyzer if it has a cancel method
        if self._current_analyzer and hasattr(self._current_analyzer, 'cancel'):
            self._current_analyzer.cancel()

    def is_cancelled(self):
        """Check if analysis was cancelled"""
        return self._is_cancelled

    def format_time(self, seconds):
        """Format time in a human-readable format"""
        if seconds < 60:
            return f"{seconds:.2f} seconds"
        elif seconds < 3600:
            minutes = int(seconds // 60)
            secs = seconds % 60
            return f"{minutes} minute(s) and {secs:.2f} seconds"
        else:
            hours = int(seconds // 3600)
            minutes = int((seconds % 3600) // 60)
            secs = seconds % 60
            return f"{hours} hour(s), {minutes} minute(s), and {secs:.2f} seconds"

    def run(self):
        # Record start time
        import time
        self.start_time = datetime.now()

        try:
            from pathlib import Path
            # Add plugin directory to path
            plugin_dir = str(Path(__file__).parent)
            if plugin_dir not in sys.path:
                sys.path.insert(0, plugin_dir)

            self.progress.emit(5, f"STARTING {self.analysis_type.upper()} ANALYSIS")
            self.output_signal.emit("info", "="*80)
            self.output_signal.emit("info", f"STARTING {self.analysis_type.upper()} ANALYSIS")
            self.output_signal.emit("info", "="*80)
            self.output_signal.emit("info", f"Analysis started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

            if self.analysis_type == 'apca':
                from apca import TimeSeriesAPCA
                import xarray as xr
                import geopandas as gpd

                self.output_signal.emit("info", f"\nInput NetCDF: {self.params['nc_file']}")
                self.output_signal.emit("info", f"Input Shapefile: {self.params['shp_file']}")
                self.output_signal.emit("info", f"Output Folder: {self.params['output_folder']}")
                self.output_signal.emit("info", f"Ice Thickness Variable: {self.params.get('thk_var', 'thk')}")

                # Load data
                self.progress.emit(10, "Loading NetCDF...")
                self.output_signal.emit("info", "\n1. Loading NetCDF file...")
                ds = xr.open_dataset(self.params['nc_file'])
                self.output_signal.emit("info", f"   Dimensions: {dict(ds.dims)}")
                self.output_signal.emit("info", f"   Variables: {list(ds.data_vars.keys())}")

                self.output_signal.emit("info", "\n2. Fixing time coordinates...")
                ds = fix_time_coordinates(ds)
                self.output_signal.emit("info", f"   Total time steps: {len(ds.time)}")

                self.output_signal.emit("info", "\n3. Loading shapefile...")
                gdf = gpd.read_file(self.params['shp_file'], engine="pyogrio")
                self.output_signal.emit("info", f"   Features: {len(gdf)}")
                self.output_signal.emit("info", f"   Geometry type: {gdf.geometry.iloc[0].geom_type}")

                # Setup output
                self.output_signal.emit("info", "\n4. Setting up output folders...")
                output_dir = Path(self.params['output_folder'])
                subdirs = {
                    'main': output_dir,
                    'plots': output_dir / 'plots',
                    'time_step_plots': output_dir / 'plots' / 'time_steps',
                    'best_match': output_dir / 'best_match',
                    'csv': output_dir / 'csv',
                    'ice_outlines': output_dir / 'ice_outlines'
                }
                for subdir in subdirs.values():
                    try:
                        subdir.mkdir(parents=True, exist_ok=True)
                    except TypeError:
                        if not subdir.exists():
                            subdir.mkdir(parents=True)

                # Create time indices
                total_times = len(ds.time)
                start_idx = self.params.get('start_idx', 0)
                end_idx = self.params.get('end_idx', total_times - 1)
                step = self.params.get('step', 1)
                time_indices = list(range(start_idx, min(end_idx + 1, total_times), step))
                self.output_signal.emit("info", f"   Time range: {start_idx} to {end_idx}, step {step}")
                self.output_signal.emit("info", f"   Analyzing {len(time_indices)} time steps")

                # Create analyzer
                self.progress.emit(20, "Creating APCA analyzer...")
                self.output_signal.emit("info", "\n5. Creating APCA analyzer...")

                base_name = os.path.basename(output_dir)

                analyzer = TimeSeriesAPCA(
                    pism_dataset=ds,
                    target_features=gdf,
                    output_subdirs=subdirs,
                    prefix=base_name,
                    time_indices=time_indices,
                    ice_threshold=self.params.get('ice_threshold', 0.5),
                    min_ice_thickness=self.params.get('min_ice_thickness', 1.0),
                    cell_size=self.params.get('cell_size', 500),
                    crs=gdf.crs,
                    ice_variable=self.params.get('thk_var', 'thk'),
                    use_accumulative_ice=self.params.get('use_accumulative_ice', True),
                    progress_callback=self.update_progress_callback,
                    cancel_checker=self.is_cancelled
                )

                self._current_analyzer = analyzer

                analyzer.set_console(lambda msg: self.emit_output("info", msg))

                self.progress.emit(30, "Analyzing APCA time series...")
                self.output_signal.emit("info", "\n6. Analyzing APCA time series...")

                time_series = analyzer.analyze_time_series(
                    id_field=self.params.get('id_field', None),
                    save_plots=self.params.get('save_plots', True),
                    save_shapefiles=self.params.get('save_shapefiles', True)
                )

                self._current_analyzer = None

                if time_series is not None:
                    self.progress.emit(90, "Generating outputs...")
                    self.output_signal.emit("info", "\n7. Generating outputs...")
                    analyzer.generate_best_match_map()
                    analyzer.plot_time_series()
                    analyzer.export_results()

                    self.progress.emit(100, "APCA analysis complete!")
                    self.output_signal.emit("info", "\n" + "="*80)
                    self.output_signal.emit("info", "APCA ANALYSIS COMPLETED SUCCESSFULLY!")
                    self.output_signal.emit("info", f"Results saved to: {output_dir}")
                    self.output_signal.emit("info", "="*80)
                    self.finished.emit(True, f"APCA analysis completed successfully!\nResults saved to: {output_dir}")
                else:
                    self.output_signal.emit("error", "\nERROR: No results generated!")
                    self.finished.emit(False, "APCA analysis failed: No results generated")

            elif self.analysis_type == 'afda':
                from afda import PISMAFDA
                import xarray as xr

                self.output_signal.emit("info", f"\nInput NetCDF: {self.params['nc_file']}")
                self.output_signal.emit("info", f"Input Shapefile: {self.params['shp_file']}")
                self.output_signal.emit("info", f"Output Folder: {self.params['output_folder']}")
                self.output_signal.emit("info", f"U-Velocity Variable: {self.params.get('u_var', 'uvelbase')}")
                self.output_signal.emit("info", f"V-Velocity Variable: {self.params.get('v_var', 'vvelbase')}")
                self.output_signal.emit("info", f"Ice Variable: {self.params.get('ice_var', 'thk')}")

                self.progress.emit(10, "Loading NetCDF...")
                self.output_signal.emit("info", "\n1. Loading NetCDF file...")
                ds = xr.open_dataset(self.params['nc_file'])
                self.output_signal.emit("info", f"   Dimensions: {dict(ds.dims)}")

                self.output_signal.emit("info", "\n2. Fixing time coordinates...")
                ds = fix_time_coordinates(ds)
                self.output_signal.emit("info", f"   Total time steps: {len(ds.time)}")

                self.output_signal.emit("info", "\n3. Using selected variables:")
                self.output_signal.emit("info", f"   U-velocity: {self.params.get('u_var', 'uvelbase')}")
                self.output_signal.emit("info", f"   V-velocity: {self.params.get('v_var', 'vvelbase')}")
                self.output_signal.emit("info", f"   Ice variable: {self.params.get('ice_var', 'thk')}")

                self.output_signal.emit("info", "\n4. Setting up output folders...")
                output_dir = Path(self.params['output_folder'])
                subdirs = {
                    'main': output_dir,
                    'plots': output_dir / 'plots',
                    'csv': output_dir / 'csv',
                    'rasters': output_dir / 'rasters'
                }
                for subdir in subdirs.values():
                    try:
                        subdir.mkdir(parents=True, exist_ok=True)
                    except TypeError:
                        if not subdir.exists():
                            subdir.mkdir(parents=True)

                total_times = len(ds.time)
                start_idx = self.params.get('start_idx', 0)
                end_idx = self.params.get('end_idx', total_times - 1)
                step = self.params.get('step', 1)
                time_indices = list(range(start_idx, min(end_idx + 1, total_times), step))
                self.output_signal.emit("info", f"   Time range: {start_idx} to {end_idx}, step {step}")
                self.output_signal.emit("info", f"   Analyzing {len(time_indices)} time steps")

                self.progress.emit(20, "Creating AFDA analyzer...")
                self.output_signal.emit("info", "\n5. Creating AFDA analyzer...")
                self.output_signal.emit("info", f"   Velocity threshold: {self.params.get('velocity_threshold', 1.0)} m/a")
                self.output_signal.emit("info", f"   Cell size: {self.params.get('cell_size', 500)} m")

                base_name = os.path.basename(output_dir)

                analyzer = PISMAFDA(
                    pism_dataset=ds,
                    shapefile_path=self.params['shp_file'],
                    output_subdirs=subdirs,
                    prefix=base_name,
                    time_indices=time_indices,
                    ice_threshold=self.params.get('ice_threshold', 0.5),
                    velocity_threshold=self.params.get('velocity_threshold', 1.0),
                    cell_size=self.params.get('cell_size', 500),
                    save_rasters=self.params.get('save_rasters', False),
                    u_var=self.params.get('u_var', 'uvelbase'),
                    v_var=self.params.get('v_var', 'vvelbase'),
                    ice_var=self.params.get('ice_var', 'thk'),
                    ice_type=self.params.get('ice_type', 'thickness'),
                    use_time_window=self.params.get('use_time_window', False),
                    window_size=self.params.get('window_size', 5),
                    use_accumulative_ice=self.params.get('use_accumulative_ice', True),
                    progress_callback=self.update_progress_callback,
                    cancel_checker=self.is_cancelled
                )

                self._current_analyzer = analyzer

                analyzer.set_console(lambda msg: self.emit_output("info", msg))

                self.progress.emit(30, "Running AFDA analysis...")
                self.output_signal.emit("info", "\n6. Running AFDA analysis...")
                results = analyzer.analyze_time_series()

                self._current_analyzer = None

                if results is not None:
                    self.progress.emit(100, "AFDA analysis complete!")
                    self.output_signal.emit("info", "\n" + "="*80)
                    self.output_signal.emit("info", "AFDA ANALYSIS COMPLETED SUCCESSFULLY!")
                    self.output_signal.emit("info", f"Results saved to: {output_dir}")
                    self.output_signal.emit("info", "="*80)
                    self.finished.emit(True, f"AFDA analysis completed successfully!\nResults saved to: {output_dir}")
                else:
                    self.output_signal.emit("error", "\nERROR: No results generated!")
                    self.finished.emit(False, "AFDA analysis failed: No results generated")

            elif self.analysis_type == 'lala':
                from lala import LALA_Analyzer
                import xarray as xr

                self.output_signal.emit("info", f"\nInput NetCDF: {self.params['nc_file']}")
                self.output_signal.emit("info", f"Input Shapefile: {self.params['shp_file']}")
                self.output_signal.emit("info", f"Output Folder: {self.params['output_folder']}")

                self.progress.emit(10, "Loading NetCDF...")
                self.output_signal.emit("info", "\n1. Loading NetCDF file...")

                ds = xr.open_dataset(self.params['nc_file'])
                self.output_signal.emit("info", f"   Dimensions: {dict(ds.dims)}")

                self.output_signal.emit("info", "\n2. Fixing time coordinates...")
                ds = fix_time_coordinates(ds)
                self.output_signal.emit("info", f"   Total time steps: {len(ds.time)}")

                self.output_signal.emit("info", "\n3. Using selected variables:")
                self.output_signal.emit("info", f"U-Velocity Variable: {self.params.get('u_var', 'uvelbase')}")
                self.output_signal.emit("info", f"V-Velocity Variable: {self.params.get('v_var', 'vvelbase')}")
                self.output_signal.emit("info", f"Thickness Variable: {self.params.get('thk_var', 'thk')}")
                self.output_signal.emit("info", f"Mask Variable: {self.params.get('mask_var', 'mask')}")

                self.output_signal.emit("info", "\n4. Setting up output folders...")
                output_dir = Path(self.params['output_folder'])
                subdirs = {
                    'main': output_dir,
                    'plots': output_dir / 'plots',
                    'csv': output_dir / 'csv',
                    'shape_files': output_dir / 'shape_files'
                }
                for subdir in subdirs.values():
                    try:
                        subdir.mkdir(parents=True, exist_ok=True)
                    except TypeError:
                        if not subdir.exists():
                            subdir.mkdir(parents=True)

                self.progress.emit(20, "Creating LALA analyzer...")
                self.output_signal.emit("info", "\n5. Creating LALA analyzer...")
                self.output_signal.emit("info", f"   Cell size: {self.params.get('cell_size', 500)} m")

                base_name = os.path.basename(output_dir)

                analyzer = LALA_Analyzer(
                    pism_dataset=ds,
                    shapefile_path=self.params['shp_file'],
                    output_subdirs=subdirs,
                    prefix=base_name,
                    thk_threshold=self.params.get('thk_threshold', 10),
                    velocity_threshold=self.params.get('velocity_threshold', 1.0),
                    u_var=self.params.get('u_var', 'uvelbase'),
                    v_var=self.params.get('v_var', 'vvelbase'),
                    thk_var=self.params.get('thk_var', 'thk'),
                    mask_var=self.params.get('mask_var', 'mask'),
                    grounded_ice=float(self.params.get('grounded_ice', '2')),
                    kappa=self.params.get('kappa', 10),
                    p_value=self.params.get('p_value', 0.01),
                    progress_callback=self.update_progress_callback,
                    cancel_checker=self.is_cancelled
                )

                self._current_analyzer = analyzer

                analyzer.set_console(lambda msg: self.emit_output("info", msg))

                self.progress.emit(30, "Running LALA analysis...")
                results = analyzer.runLALA()

                self._current_analyzer = None

                if results is not None:
                    self.progress.emit(100, "LALA analysis complete!")
                    self.output_signal.emit("info", "\n" + "="*80)
                    self.output_signal.emit("info", "LALA ANALYSIS COMPLETED SUCCESSFULLY!")
                    self.output_signal.emit("info", f"Results saved to: {output_dir}")
                    self.output_signal.emit("info", "="*80)
                    self.finished.emit(True, f"LALA analysis completed successfully!\nResults saved to: {output_dir}")
                else:
                    self.output_signal.emit("error", "\nERROR: No results generated!")
                    self.finished.emit(False, "LALA analysis failed: No results generated")

            elif self.analysis_type == 'overlap':
                from overlap import OutlineOverlapAnalyzer
                import xarray as xr
                import geopandas as gpd

                self.output_signal.emit("info", f"\nInput NetCDF: {self.params['nc_file']}")
                self.output_signal.emit("info", f"Input Shapefile: {self.params['shp_file']}")
                self.output_signal.emit("info", f"Output Folder: {self.params['output_folder']}")

                self.progress.emit(10, "Loading NetCDF...")
                ds = xr.open_dataset(self.params['nc_file'], decode_times=False)
                ds = fix_time_coordinates(ds)

                self.progress.emit(20, "Loading shapefile...")
                gdf = gpd.read_file(self.params['shp_file'], engine="pyogrio")

                output_dir = Path(self.params['output_folder'])
                subdirs = {
                    'main': output_dir,
                    'plots': output_dir / 'plots',
                    'time_step_plots': output_dir / 'plots' / 'time_steps',
                    'best_match': output_dir / 'best_match',
                    'csv': output_dir / 'csv',
                    'rasters': output_dir / 'rasters'
                }
                for subdir in subdirs.values():
                    subdir.mkdir(parents=True, exist_ok=True)

                total_times = len(ds.time)
                start_idx = self.params.get('start_idx', 0)
                end_idx = self.params.get('end_idx', total_times - 1)
                step = self.params.get('step', 1)
                time_indices = list(range(start_idx, min(end_idx + 1, total_times), step))

                base_name = os.path.basename(output_dir)

                analyzer = OutlineOverlapAnalyzer(
                    pism_dataset=ds,
                    field_gdf=gdf,
                    output_subdirs=subdirs,
                    prefix=base_name,
                    time_indices=time_indices,
                    min_ice_thickness=self.params.get('min_ice_thickness', 1.0),
                    cell_size=self.params.get('cell_size', 500),
                    ice_variable=self.params.get('thk_var', 'thk'),
                    use_time_window=self.params.get('use_time_window', False),
                    window_size=self.params.get('window_size', 5),
                    use_accumulative_ice=self.params.get('use_accumulative_ice', True),
                    min_polygon_area_km2=self.params.get('min_polygon_area_km2', 0.01),
                    id_field=self.params.get('id_field', None),
                    progress_callback=self.update_progress_callback,
                    cancel_checker=self.is_cancelled,
                    save_rasters=self.params.get('save_rasters', False),
                    save_plots=self.params.get('save_plots', True)
                )

                self._current_analyzer = analyzer

                analyzer.set_console(lambda msg: self.emit_output("info", msg))

                results = analyzer.analyze_time_series(
                    save_plots=self.params.get('save_plots', True),
                    save_rasters=self.params.get('save_rasters', False),
                    use_parallel=False,
                    max_workers=None
                )

                self._current_analyzer = None

                if results is not None:
                    analyzer.generate_best_match_map()
                    self.output_signal.emit("info", "\n" + "="*80)
                    self.output_signal.emit("info", "OVERLAP ANALYSIS COMPLETED SUCCESSFULLY!")
                    self.output_signal.emit("info", f"Results saved to: {output_dir}")
                    self.output_signal.emit("info", "="*80)
                    self.finished.emit(True, f"Overlap analysis completed!\nBest F1-Score: {analyzer.best_match_f1:.4f} at time step {analyzer.best_match_time}")
                else:
                    self.finished.emit(False, "Overlap analysis failed: No results generated")

            elif self.analysis_type == 'polygon_overlap':
                from overlap_polygon import PolygonOverlapAnalyzer
                import xarray as xr
                import geopandas as gpd

                self.output_signal.emit("info", f"\nInput NetCDF: {self.params['nc_file']}")
                self.output_signal.emit("info", f"Input Shapefile: {self.params['shp_file']}")
                self.output_signal.emit("info", f"Output Folder: {self.params['output_folder']}")

                self.progress.emit(10, "Loading NetCDF...")
                ds = xr.open_dataset(self.params['nc_file'], decode_times=False)
                ds = fix_time_coordinates(ds)

                self.progress.emit(20, "Loading shapefile...")
                gdf = gpd.read_file(self.params['shp_file'], engine="pyogrio")

                output_dir = Path(self.params['output_folder'])
                subdirs = {
                    'main': output_dir,
                    'plots': output_dir / 'plots',
                    'time_step_plots': output_dir / 'plots' / 'time_steps',
                    'best_match': output_dir / 'best_match',
                    'csv': output_dir / 'csv',
                    'shapefiles': output_dir / 'shapefiles'
                }
                for subdir in subdirs.values():
                    subdir.mkdir(parents=True, exist_ok=True)

                total_times = len(ds.time)
                start_idx = self.params.get('start_idx', 0)
                end_idx = self.params.get('end_idx', total_times - 1)
                step = self.params.get('step', 1)
                time_indices = list(range(start_idx, min(end_idx + 1, total_times), step))

                base_name = os.path.basename(output_dir)

                analyzer = PolygonOverlapAnalyzer(
                    pism_dataset=ds,
                    field_gdf=gdf,
                    output_subdirs=subdirs,
                    prefix=base_name,
                    time_indices=time_indices,
                    min_ice_thickness=self.params.get('min_ice_thickness', 1.0),
                    ice_variable=self.params.get('thk_var', 'thk'),
                    use_time_window=self.params.get('use_time_window', False),
                    window_size=self.params.get('window_size', 5),
                    use_accumulative_ice=self.params.get('use_accumulative_ice', False),
                    id_field=self.params.get('id_field', None),
                    min_polygon_area_km2=self.params.get('min_polygon_area_km2', 0.01),
                    progress_callback=self.update_progress_callback,
                    cancel_checker=self.is_cancelled
                )

                self._current_analyzer = analyzer

                analyzer.set_console(lambda msg: self.emit_output("info", msg))

                results = analyzer.analyze_time_series(
                    save_plots=self.params.get('save_plots', True),
                    save_shapefiles=self.params.get('save_shapefiles', False),
                    use_parallel=False,
                    max_workers=None
                )

                self._current_analyzer = None

                if results is not None:
                    self.output_signal.emit("info", "\n" + "="*80)
                    self.output_signal.emit("info", "POLYGON-BASED OVERLAP ANALYSIS COMPLETED SUCCESSFULLY!")
                    self.output_signal.emit("info", f"Results saved to: {output_dir}")
                    self.output_signal.emit("info", "="*80)
                    self.finished.emit(True, f"Polygon-based overlap analysis completed!\nBest F1-Score: {analyzer.best_match_f1:.4f}")
                else:
                    self.finished.emit(False, "Polygon-based overlap analysis failed: No results generated")

            elif self.analysis_type == 'point_compare':
                from point_compare import PointCompareAnalyzer
                import xarray as xr
                import geopandas as gpd

                self.output_signal.emit("info", f"\nInput NetCDF: {self.params['nc_file']}")
                self.output_signal.emit("info", f"Input Points: {self.params['shp_file']}")
                self.output_signal.emit("info", f"Output Folder: {self.params['output_folder']}")
                self.output_signal.emit("info", f"Variable: {self.params['var_name']}")

                self.progress.emit(10, "Loading NetCDF...")
                ds = xr.open_dataset(self.params['nc_file'], decode_times=False)
                ds = fix_time_coordinates(ds)

                self.progress.emit(20, "Loading shapefile...")
                gdf = gpd.read_file(self.params['shp_file'], engine="pyogrio")

                output_dir = Path(self.params['output_folder'])
                subdirs = {
                    'main': output_dir,
                    'plots': output_dir / 'plots',
                    'time_step_plots': output_dir / 'plots' / 'time_steps',
                    'best_match': output_dir / 'best_match',
                    'csv': output_dir / 'csv'
                }
                for subdir in subdirs.values():
                    subdir.mkdir(parents=True, exist_ok=True)

                total_times = len(ds.time)
                start_idx = self.params.get('start_idx', 0)
                end_idx = self.params.get('end_idx', total_times - 1)
                step = self.params.get('step', 1)
                time_indices = list(range(start_idx, min(end_idx + 1, total_times), step))

                base_name = os.path.basename(output_dir)

                analyzer = PointCompareAnalyzer(
                    pism_dataset=ds,
                    points_gdf=gdf,
                    output_subdirs=subdirs,
                    prefix=base_name,
                    time_indices=time_indices,
                    var_name=self.params.get('var_name', 'usurf'),
                    use_time_window=self.params.get('use_time_window', False),
                    window_size=self.params.get('window_size', 5),
                    value_field=self.params.get('value_field', None),
                    id_field=self.params.get('id_field', None),
                    min_ice_thickness=self.params.get('min_ice_thickness', 1.0),
                    use_accumulative=self.params.get('use_accumulative', False),
                    save_plots=self.params.get('save_plots', True),
                    progress_callback=self.update_progress_callback,
                    cancel_checker=self.is_cancelled
                )

                analyzer.set_console(lambda msg: self.emit_output("info", msg))

                self._current_analyzer = analyzer

                results = analyzer.analyze_time_series(
                    use_parallel=True,
                    max_workers=6
                )

                self._current_analyzer = analyzer

                if results is not None:
                    self.output_signal.emit("info", "\n" + "="*80)
                    self.output_signal.emit("info", "POINT COMPARISON ANALYSIS COMPLETED SUCCESSFULLY!")
                    self.output_signal.emit("info", f"Results saved to: {output_dir}")
                    self.output_signal.emit("info", "="*80)
                    self.finished.emit(True, f"Point comparison completed!\nBest RMSE: {analyzer.best_match_rmse:.2f}m at time step {analyzer.best_match_time}")
                else:
                    self.finished.emit(False, "Point comparison analysis failed: No results generated")

            elif self.analysis_type == 'raster_to_nc':
                from raster_to_nc import RasterToNetCDFConverter

                converter = RasterToNetCDFConverter(
                    thick_folder=self.params['thick_folder'],
                    output_nc=self.params['output_nc'],
                    surface_folder=self.params.get('surface_folder', None),
                    uvel_folder=self.params.get('uvel_folder', None),
                    vvel_folder=self.params.get('vvel_folder', None),
                    start_idx=self.params.get('start_idx', None),
                    end_idx=self.params.get('end_idx', None),
                    step=self.params.get('step', None),
                    use_compression=self.params.get('use_compression', True),
                    fill_value=-9999.0,
                    progress_callback=self.update_progress_callback,
                    cancel_checker=self.is_cancelled
                )

                converter.set_console(lambda msg: self.emit_output("info", msg))

                self._current_analyzer = converter

                output_file = converter.convert()

                self._current_analyzer = None

                if output_file:
                    self.output_signal.emit("info", "\n" + "="*80)
                    self.output_signal.emit("info", "RASTER TO NETCDF CONVERSION COMPLETED SUCCESSFULLY!")
                    self.output_signal.emit("info", f"Output file: {output_file}")
                    self.output_signal.emit("info", "="*80)
                    self.finished.emit(True, f"Conversion completed successfully!\nOutput: {output_file}")
                else:
                    self.finished.emit(False, "Conversion failed")

            # Calculate elapsed time
            end_time = datetime.now()
            elapsed_seconds = (end_time - self.start_time).total_seconds()
            elapsed_formatted = self.format_time(elapsed_seconds)

            if self._is_cancelled:
                self.output_signal.emit("warning", f"\nAnalysis was cancelled by user after {elapsed_formatted}.")
                self.finished.emit(False, f"Analysis cancelled by user after {elapsed_formatted}.")
            else:
                self.output_signal.emit("info", "\n" + "="*80)
                self.output_signal.emit("info", f"ANALYSIS COMPLETED SUCCESSFULLY!")
                self.output_signal.emit("info", f"Total runtime: {elapsed_formatted}")
                self.output_signal.emit("info", "="*80)

        except Exception as e:
            end_time = datetime.now()
            elapsed_seconds = (end_time - self.start_time).total_seconds()
            elapsed_formatted = self.format_time(elapsed_seconds)

            if not self._is_cancelled:
                import traceback
                error_msg = f"Error: {str(e)}\n\n{traceback.format_exc()}"
                self.output_signal.emit("error", f"\nERROR: {error_msg}")
                self.output_signal.emit("info", f"Failed after {elapsed_formatted}")
                self.finished.emit(False, f"Analysis failed after {elapsed_formatted}:\n{str(e)}")
            else:
                self.finished.emit(False, f"Analysis cancelled after {elapsed_formatted}")


class GlacierAnalysisToolkitDialog(QDialog):
    """Main dialog for Glacier Analysis Toolkit"""

    accepted = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("GLIMAT - Glacial Lineation, Ice Margin, Area & Thickness Assessment Toolkit")
        self.setMinimumSize(900, 850)

        self.nc_file = ""
        self.shp_file = ""
        self.output_folder = ""
        self.worker = None
        self.current_ds = None

        self.setup_ui()

    def append_console(self, message, tag="info"):
        """Add message to console (thread-safe, no re-entrant event pumping).

        WARNING: Do NOT call QApplication.processEvents() in this method.
        Doing so re-enters the Qt event loop from inside a signal handler,
        which re-dispatches queued output_signal events back into this same
        slot, recursively, until the native (C) thread stack overflows and
        Windows kills the process with STATUS_STACK_OVERFLOW.
        """
        # Re-entrancy guard: if a queued signal handler calls us back into
        # ourselves before the previous call returns, bail out immediately.
        if getattr(self, '_in_append_console', False):
            return
        self._in_append_console = True
        try:
            timestamp = datetime.now().strftime("%H:%M:%S")

            if tag == "error":
                color = "red"
            elif tag == "warning":
                color = "orange"
            elif tag == "info":
                color = "lightgreen"
            else:
                color = "white"

            # HTML-escape the body so filenames / tracebacks containing
            # '<', '>', '&' don't break the rich-text layout.
            safe = (str(message)
                    .replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\n", "<br>"))

            formatted = f'<span style="color:{color}">[{timestamp}] {safe}</span>'

            self.console.appendHtml(formatted)

            # Auto-scroll to bottom
            cursor = self.console.textCursor()
            cursor.movePosition(QTextCursor.MoveOperation.End)
            self.console.setTextCursor(cursor)

            # Qt will repaint when control returns to the event loop.

            QgsMessageLog.logMessage(str(message), "GLIMAT", Qgis.Info)
        finally:
            self._in_append_console = False

    def setup_ui(self):
        """Setup the user interface"""
        main_layout = QVBoxLayout()

        splitter = QSplitter(Qt.Orientation.Vertical)

        # Top section: Parameters
        param_widget = QWidget()
        param_layout = QVBoxLayout(param_widget)

        # Create tab widget
        self.tab_widget = QTabWidget()

        # APCA tab
        self.apca_tab = self.create_apca_tab()
        self.tab_widget.addTab(self.apca_tab, "APCA")

        # AFDA tab
        self.afda_tab = self.create_afda_tab()
        self.tab_widget.addTab(self.afda_tab, "AFDA")

        # LALA tab
        self.lala_tab = self.create_lala_tab()
        self.tab_widget.addTab(self.lala_tab, "LALA")

        # Polygon-based Overlap tab
        self.polygon_overlap_tab = self.create_polygon_overlap_tab()
        self.tab_widget.addTab(self.polygon_overlap_tab, "APOA")

        # Point Comparison tab
        self.point_compare_tab = self.create_point_compare_tab()
        self.tab_widget.addTab(self.point_compare_tab, "STPC")

        # TIFF to NetCDF Converter tab
        self.raster_to_nc_tab = self.create_raster_to_nc_tab()
        self.tab_widget.addTab(self.raster_to_nc_tab, "TIF/ASC to NC")

        param_layout.addWidget(self.tab_widget)

        # Progress bar (hidden initially)
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        param_layout.addWidget(self.progress_bar)

        splitter.addWidget(param_widget)

        # Bottom section: Console output
        console_group = QGroupBox("Console Output")
        console_layout = QVBoxLayout()

        self.console = QPlainTextEdit()
        self.console.setReadOnly(True)
        self.console.setFont(QFont("Consolas", 10))
        self.console.setStyleSheet("""
            QPlainTextEdit {
                background-color: black;
                color: white;
                font-family: Consolas;
                font-size: 10pt;
            }
        """)
        console_layout.addWidget(self.console)

        # Button row
        button_layout = QHBoxLayout()

        self.run_button = QPushButton("Run Analysis")
        self.run_button.clicked.connect(self.on_run_clicked)
        button_layout.addWidget(self.run_button)

        self.stop_button = QPushButton("Stop")
        self.stop_button.clicked.connect(self.on_stop_clicked)
        self.stop_button.setEnabled(False)
        button_layout.addWidget(self.stop_button)

        clear_button = QPushButton("Clear Console")
        clear_button.clicked.connect(self.clear_console)
        button_layout.addWidget(clear_button)

        save_button = QPushButton("Save Console")
        save_button.clicked.connect(self.save_console)
        button_layout.addWidget(save_button)

        button_layout.addStretch()

        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.clicked.connect(self.reject)
        button_layout.addWidget(self.cancel_button)

        console_layout.addLayout(button_layout)

        console_group.setLayout(console_layout)
        splitter.addWidget(console_group)

        splitter.setSizes([500, 350])

        main_layout.addWidget(splitter)

        self.setLayout(main_layout)

        # Initial console message
        self.append_console("="*80)
        self.append_console("GLIMAT Toolkit Ready")
        self.append_console("="*80)
        self.append_console("Select analysis type, input files, and parameters.")
        self.append_console("After selecting a NetCDF file, click 'Refresh Variables' to auto-detect.")
        self.append_console("Click 'Run Analysis' to start.")
        self.append_console("")

    def load_netcdf_variables(self, nc_file_path, tab_name):
        """Load and display NetCDF variables for selection"""
        try:
            if not os.path.exists(nc_file_path):
                return

            self.append_console(f"\nLoading variables from: {nc_file_path}")
            ds = xr.open_dataset(nc_file_path)

            variables = list(ds.data_vars.keys())
            self.append_console(f"Found {len(variables)} variables: {', '.join(variables[:10])}...")

            u_candidates = []
            v_candidates = []
            thk_candidates = []
            mask_candidates = []

            for var in variables:
                var_lower = var.lower()
                if any(x in var_lower for x in ['uvelsurf', 'uvelbase', 'uvel', 'u_vel', 'ubar', 'u_velocity', 'velx', 'vx']):
                    u_candidates.append(var)
                if any(x in var_lower for x in ['vvelsurf', 'vvelbase', 'vvel', 'v_vel', 'vbar', 'v_velocity', 'vely', 'vy']):
                    v_candidates.append(var)

                exact_thk_names = ['thk', 'thickness', 'ice_thickness', 'land_ice_thickness']
                if var_lower in exact_thk_names:
                    thk_candidates.append(var)
                exact_ice_names = ['mask', 'ice_mask', 'ice_fraction', 'land_ice_area_fraction']
                if var_lower in exact_ice_names:
                    mask_candidates.append(var)

            if tab_name == 'afda':
                self.u_var_combo.clear()
                self.v_var_combo.clear()
                self.ice_var_combo.clear()

                for var in u_candidates:
                    self.u_var_combo.addItem(var)
                for var in v_candidates:
                    self.v_var_combo.addItem(var)
                for var in thk_candidates + mask_candidates:
                    self.ice_var_combo.addItem(var)

                self.u_var_combo.addItem("-- Select from list --")
                self.v_var_combo.addItem("-- Select from list --")
                self.ice_var_combo.addItem("-- Select from list --")

                for var in variables:
                    self.u_var_combo.addItem(var)
                    self.v_var_combo.addItem(var)
                    self.ice_var_combo.addItem(var)

                if u_candidates:
                    self.u_var_combo.setCurrentText(u_candidates[0])
                if v_candidates:
                    self.v_var_combo.setCurrentText(v_candidates[0])
                if thk_candidates:
                    self.ice_var_combo.setCurrentText(thk_candidates[0])
                elif mask_candidates:
                    self.ice_var_combo.setCurrentText(mask_candidates[0])

                self.append_console(f"  U-velocity candidates: {u_candidates}")
                self.append_console(f"  V-velocity candidates: {v_candidates}")
                self.append_console(f"  Ice thickness candidates: {thk_candidates}")

            elif tab_name == 'lala':
                self.u_var_combo.clear()
                self.v_var_combo.clear()
                self.thk_var_combo.clear()
                self.mask_var_combo.clear()

                for var in u_candidates:
                    self.u_var_combo.addItem(var)
                for var in v_candidates:
                    self.v_var_combo.addItem(var)
                for var in thk_candidates:
                    self.ice_var_combo.addItem(var)
                for var in mask_candidates:
                    self.mask_var_combo.addItem(var)

                self.u_var_combo.addItem("-- Select from list --")
                self.v_var_combo.addItem("-- Select from list --")
                self.mask_var_combo.addItem("-- Select from list --")
                self.thk_var_combo.addItem("-- Select from list --")

                for var in variables:
                    self.u_var_combo.addItem(var)
                    self.v_var_combo.addItem(var)
                    self.mask_var_combo.addItem(var)
                    self.thk_var_combo.addItem(var)

                if u_candidates:
                    self.u_var_combo.setCurrentText(u_candidates[0])
                if v_candidates:
                    self.v_var_combo.setCurrentText(v_candidates[0])
                if thk_candidates:
                    self.thk_var_combo.setCurrentText(thk_candidates[0])
                if mask_candidates:
                    self.mask_var_combo.setCurrentText(mask_candidates[0])

                self.append_console(f"  U-velocity candidates: {u_candidates}")
                self.append_console(f"  V-velocity candidates: {v_candidates}")
                self.append_console(f"  Ice thickness candidates: {thk_candidates}")
                self.append_console(f"  mask candidates: {mask_candidates}")

            elif tab_name == 'apca':
                self.thk_var_combo.clear()

                for var in thk_candidates:
                    self.thk_var_combo.addItem(var)

                self.thk_var_combo.addItem("-- Select from list --")
                for var in variables:
                    self.thk_var_combo.addItem(var)

                if thk_candidates:
                    self.thk_var_combo.setCurrentText(thk_candidates[0])

                self.append_console(f"  Ice thickness candidates: {thk_candidates}")

            elif tab_name == 'overlap':
                self.thk_var_combo_overlap.clear()

                for var in thk_candidates:
                    self.thk_var_combo_overlap.addItem(var)

                self.thk_var_combo_overlap.addItem("-- Select from list --")
                for var in variables:
                    self.thk_var_combo_overlap.addItem(var)

                if thk_candidates:
                    self.thk_var_combo_overlap.setCurrentText(thk_candidates[0])

                self.append_console(f"  Ice thickness candidates: {thk_candidates}")

            elif tab_name == 'polygon':
                self.thk_var_combo_polygon.clear()

                for var in thk_candidates:
                    self.thk_var_combo_polygon.addItem(var)

                self.thk_var_combo_polygon.addItem("-- Select from list --")
                for var in variables:
                    self.thk_var_combo_polygon.addItem(var)

                if thk_candidates:
                    self.thk_var_combo_polygon.setCurrentText(thk_candidates[0])

                self.append_console(f"  Ice thickness candidates: {thk_candidates}")

            else:  # 'point'
                self.var_combo_point.clear()
                self.thick_var_combo_point.clear()

                for var in thk_candidates:
                    self.thick_var_combo_point.addItem(var)

                for var in variables:
                    self.var_combo_point.addItem(var)
                    self.thick_var_combo_point.addItem(var)

                self.var_combo_point.addItem("-- Select from list --")
                self.thick_var_combo_point.addItem("-- Select from list --")

                if thk_candidates:
                    self.var_combo_point.setCurrentText(thk_candidates[0])
                    self.thick_var_combo_point.setCurrentText(thk_candidates[0])

                self.append_console(f"  Thickness variable candidates: {thk_candidates}")

            ds.close()
            self.append_console("Variable detection complete.\n")

        except Exception as e:
            self.append_console(f"Error loading variables: {str(e)}")

    def toggle_afda_window_options(self, checked):
        """Enable/disable window options based on checkbox"""
        self.window_size_spin.setEnabled(checked)
        self.accumulative_ice_afda.setEnabled(checked)

    def toggle_apca_window_options(self, checked):
        """Enable/disable APCA window options based on checkbox"""
        self.window_size_apca.setEnabled(checked)
        self.accumulative_ice_apca.setEnabled(checked)

    def toggle_overlap_window_options(self, checked):
        """Enable/disable overlap window options"""
        self.window_size_overlap.setEnabled(checked)
        self.accumulative_ice_overlap.setEnabled(checked)

    def toggle_polygon_window_options(self, checked):
        """Enable/disable polygon overlap window options"""
        self.window_size_polygon.setEnabled(checked)
        self.accumulative_ice_polygon.setEnabled(checked)

    def toggle_point_window_options(self, checked):
        """Enable/disable point comparison window options"""
        self.window_size_point.setEnabled(checked)
        self.accumulative_point.setEnabled(checked)

    def create_apca_tab(self):
        """Create APCA tab widgets with variable selection"""
        tab = QWidget()
        layout = QVBoxLayout()

        input_group = QGroupBox("Input Files")
        input_layout = QFormLayout()

        nc_layout = QHBoxLayout()
        self.nc_line_edit_apca = QLineEdit()
        nc_button = QPushButton("Browse...")
        nc_button.clicked.connect(lambda: self.select_nc_file('apca'))
        nc_layout.addWidget(self.nc_line_edit_apca)
        nc_layout.addWidget(nc_button)
        input_layout.addRow("Modelled NetCDF File:", nc_layout)

        var_layout = QHBoxLayout()
        self.thk_var_combo = QComboBox()
        self.thk_var_combo.setEditable(True)
        self.thk_var_combo.setMinimumWidth(200)
        self.thk_var_combo.addItem("thk")
        self.thk_var_combo.addItem("land_ice_thickness")
        self.thk_var_combo.addItem("ice_thickness")
        var_layout.addWidget(self.thk_var_combo)

        refresh_button = QPushButton("Refresh Variables")
        refresh_button.clicked.connect(lambda: self.refresh_variables('apca'))
        var_layout.addWidget(refresh_button)
        input_layout.addRow("Ice Thickness Variable:", var_layout)

        shp_layout = QHBoxLayout()
        self.shp_line_edit_apca = QLineEdit()
        shp_button = QPushButton("Browse...")
        shp_button.clicked.connect(lambda: self.select_shp_file('apca'))
        shp_layout.addWidget(self.shp_line_edit_apca)
        shp_layout.addWidget(shp_button)
        input_layout.addRow("Field Ice Margin Shapefile:", shp_layout)

        id_layout = QHBoxLayout()
        self.id_field_combo = QComboBox()
        self.id_field_combo.setEnabled(False)
        self.id_field_combo.setToolTip("Select field to group glacier outlines (e.g., glacier ID)")
        id_layout.addWidget(self.id_field_combo)

        refresh_id_button = QPushButton("Refresh Fields")
        refresh_id_button.clicked.connect(lambda: self.refresh_shapefile_fields('apca'))
        refresh_id_button.setEnabled(False)
        id_layout.addWidget(refresh_id_button)
        input_layout.addRow("Group by Field (ID):", id_layout)

        out_layout = QHBoxLayout()
        self.out_line_edit_apca = QLineEdit()
        out_button = QPushButton("Browse...")
        out_button.clicked.connect(lambda: self.select_output_folder('apca'))
        out_layout.addWidget(self.out_line_edit_apca)
        out_layout.addWidget(out_button)
        input_layout.addRow("Output Folder:", out_layout)

        input_group.setLayout(input_layout)
        layout.addWidget(input_group)

        param_group = QGroupBox("Analysis Parameters")
        param_layout = QFormLayout()

        time_layout = QHBoxLayout()
        time_layout.setSpacing(5)

        self.start_spin_apca = QSpinBox()
        self.start_spin_apca.setRange(0, 9999)
        self.start_spin_apca.setValue(0)
        time_layout.addWidget(self.start_spin_apca)

        end_label = QLabel("End:")
        end_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        time_layout.addWidget(end_label)
        self.end_spin_apca = QSpinBox()
        self.end_spin_apca.setRange(0, 9999)
        self.end_spin_apca.setValue(0)
        time_layout.addWidget(self.end_spin_apca)

        step_label = QLabel("Step:")
        step_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        time_layout.addWidget(step_label)
        self.step_spin_apca = QSpinBox()
        self.step_spin_apca.setRange(1, 100)
        self.step_spin_apca.setValue(1)
        time_layout.addWidget(self.step_spin_apca)
        param_layout.addRow("Time Range Start:", time_layout)

        threshold_layout = QHBoxLayout()
        threshold_layout.setSpacing(5)

        self.cell_size_apca = QDoubleSpinBox()
        self.cell_size_apca.setRange(10, 10000)
        self.cell_size_apca.setValue(500)
        self.cell_size_apca.setSuffix(" m")
        threshold_layout.addWidget(self.cell_size_apca)

        ice_label = QLabel("Ice Threshold:")
        ice_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        threshold_layout.addWidget(ice_label)

        self.ice_threshold_apca = QDoubleSpinBox()
        self.ice_threshold_apca.setRange(0, 1)
        self.ice_threshold_apca.setSingleStep(0.05)
        self.ice_threshold_apca.setValue(0.5)
        threshold_layout.addWidget(self.ice_threshold_apca)

        velocity_label = QLabel("Min Ice Thickness:")
        velocity_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        threshold_layout.addWidget(velocity_label)

        self.min_thickness_apca = QDoubleSpinBox()
        self.min_thickness_apca.setRange(0, 100)
        self.min_thickness_apca.setValue(1.0)
        self.min_thickness_apca.setSuffix(" m")
        threshold_layout.addWidget(self.min_thickness_apca)

        param_layout.addRow("Cell Size:", threshold_layout)

        moving_window_layout = QHBoxLayout()
        moving_window_layout.setSpacing(5)

        self.use_window_apca = QCheckBox()
        self.use_window_apca.setChecked(False)
        self.use_window_apca.toggled.connect(self.toggle_apca_window_options)
        moving_window_layout.addWidget(self.use_window_apca)

        size_label = QLabel("Size:")
        size_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        moving_window_layout.addWidget(size_label)

        self.window_size_apca = QSpinBox()
        self.window_size_apca.setRange(1, 101)
        self.window_size_apca.setSingleStep(2)
        self.window_size_apca.setValue(9)
        self.window_size_apca.setEnabled(False)
        self.window_size_apca.setToolTip("Window size (odd number)")
        moving_window_layout.addWidget(self.window_size_apca)

        mask_label = QLabel("Accumulative:")
        mask_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        moving_window_layout.addWidget(mask_label)

        self.accumulative_ice_apca = QCheckBox()
        self.accumulative_ice_apca.setChecked(True)
        self.accumulative_ice_apca.setEnabled(False)
        self.accumulative_ice_apca.setToolTip(
            "If checked: ice present if ANY step in window has ice\n"
            "If unchecked: ice present if ALL steps have ice (consistent)"
        )
        moving_window_layout.addWidget(self.accumulative_ice_apca)
        param_layout.addRow("Enable Moving Time Window:", moving_window_layout)

        save_layout = QHBoxLayout()
        save_layout.setSpacing(5)

        self.save_shapefiles_apca = QCheckBox()
        self.save_shapefiles_apca.setChecked(False)
        self.save_shapefiles_apca.setToolTip("Save model ice polygons as shapefiles for each time step")
        save_layout.addWidget(self.save_shapefiles_apca)

        save_plot_label = QLabel("Save time step plots:")
        save_plot_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        save_layout.addWidget(save_plot_label)

        self.save_plots_apca = QCheckBox()
        self.save_plots_apca.setChecked(True)
        self.save_plots_apca.setToolTip("Save PNG plots for each time step")
        save_layout.addWidget(self.save_plots_apca)

        param_layout.addRow("Save time step shapefiles:", save_layout)

        param_group.setLayout(param_layout)
        layout.addWidget(param_group)

        info_text = QTextEdit()
        info_text.setReadOnly(True)
        info_text.setMaximumHeight(150)
        info_text.setText(
            "Enhanced Automated Proximity and Conformity Analysis (APCA) with moving time window support for ice mask extraction:\n"
            "  - Smooth ice masks within each time window using accumulative or consistent ice presence\n"
            "  - Calculates mean and standard deviation offsets between modeled and field-mapped ice margins\n"
            "  - Generates ice cover map for the best match time with field ice margin overlay\n"
            "  - Identifies best match time (smallest offset)\n"
            "  - Saves shapefiles and plots for each time step to organized output directory\n"
        )
        layout.addWidget(info_text)

        layout.addStretch()
        tab.setLayout(layout)
        return tab

    def create_afda_tab(self):
        """Create AFDA tab widgets with variable selection"""
        tab = QWidget()
        layout = QVBoxLayout()

        input_group = QGroupBox("Input Files")
        input_layout = QFormLayout()

        nc_layout = QHBoxLayout()
        self.nc_line_edit_afda = QLineEdit()
        nc_button = QPushButton("Browse...")
        nc_button.clicked.connect(lambda: self.select_nc_file('afda'))
        nc_layout.addWidget(self.nc_line_edit_afda)
        nc_layout.addWidget(nc_button)
        input_layout.addRow("Modelled NetCDF File:", nc_layout)

        var_group = QGroupBox("Variable Selection")
        var_layout = QFormLayout()

        u_layout = QHBoxLayout()
        self.u_var_combo = QComboBox()
        self.u_var_combo.setEditable(True)
        self.u_var_combo.setMinimumWidth(200)
        self.u_var_combo.addItem("uvelbase")
        self.u_var_combo.addItem("uvelsurf")
        self.u_var_combo.addItem("uvel")
        self.u_var_combo.addItem("ubar")
        u_layout.addWidget(self.u_var_combo)
        var_layout.addRow("U-Velocity Variable:", u_layout)

        v_layout = QHBoxLayout()
        self.v_var_combo = QComboBox()
        self.v_var_combo.setEditable(True)
        self.v_var_combo.setMinimumWidth(200)
        self.v_var_combo.addItem("vvelbase")
        self.v_var_combo.addItem("vvelsurf")
        self.v_var_combo.addItem("vvel")
        self.v_var_combo.addItem("vbar")
        v_layout.addWidget(self.v_var_combo)
        var_layout.addRow("V-Velocity Variable:", v_layout)

        ice_layout = QHBoxLayout()
        self.ice_var_combo = QComboBox()
        self.ice_var_combo.setEditable(True)
        self.ice_var_combo.setMinimumWidth(200)
        self.ice_var_combo.addItem("thk")
        self.ice_var_combo.addItem("land_ice_thickness")
        self.ice_var_combo.addItem("mask")
        self.ice_var_combo.addItem("land_ice_area_fraction")
        ice_layout.addWidget(self.ice_var_combo)
        var_layout.addRow("Ice Variable:", ice_layout)

        self.ice_type_combo = QComboBox()
        self.ice_type_combo.addItem("thickness")
        self.ice_type_combo.addItem("fraction")
        self.ice_type_combo.addItem("mask")
        var_layout.addRow("Ice Variable Type:", self.ice_type_combo)

        refresh_button = QPushButton("Refresh Variables from NetCDF")
        refresh_button.clicked.connect(lambda: self.refresh_variables('afda'))
        var_layout.addRow("", refresh_button)

        var_group.setLayout(var_layout)
        input_layout.addRow("", var_group)

        shp_layout = QHBoxLayout()
        self.shp_line_edit_afda = QLineEdit()
        shp_button = QPushButton("Browse...")
        shp_button.clicked.connect(lambda: self.select_shp_file('afda'))
        shp_layout.addWidget(self.shp_line_edit_afda)
        shp_layout.addWidget(shp_button)
        input_layout.addRow("Flow Lineations Shapefile:", shp_layout)

        out_layout = QHBoxLayout()
        self.out_line_edit_afda = QLineEdit()
        out_button = QPushButton("Browse...")
        out_button.clicked.connect(lambda: self.select_output_folder('afda'))
        out_layout.addWidget(self.out_line_edit_afda)
        out_layout.addWidget(out_button)
        input_layout.addRow("Output Folder:", out_layout)

        input_group.setLayout(input_layout)
        layout.addWidget(input_group)

        param_group = QGroupBox("Analysis Parameters")
        param_layout = QFormLayout()

        time_layout = QHBoxLayout()
        time_layout.setSpacing(5)

        self.start_spin_afda = QSpinBox()
        self.start_spin_afda.setRange(0, 9999)
        self.start_spin_afda.setValue(0)
        time_layout.addWidget(self.start_spin_afda)

        end_label = QLabel("End:")
        end_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        time_layout.addWidget(end_label)
        self.end_spin_afda = QSpinBox()
        self.end_spin_afda.setRange(0, 9999)
        self.end_spin_afda.setValue(0)
        time_layout.addWidget(self.end_spin_afda)

        step_label = QLabel("Step:")
        step_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        time_layout.addWidget(step_label)
        self.step_spin_afda = QSpinBox()
        self.step_spin_afda.setRange(1, 100)
        self.step_spin_afda.setValue(1)
        time_layout.addWidget(self.step_spin_afda)
        param_layout.addRow("Time Range Start:", time_layout)

        threshold_layout = QHBoxLayout()
        threshold_layout.setSpacing(5)

        self.cell_size_afda = QDoubleSpinBox()
        self.cell_size_afda.setRange(10, 10000)
        self.cell_size_afda.setValue(500)
        self.cell_size_afda.setSuffix(" m")
        threshold_layout.addWidget(self.cell_size_afda)

        ice_label = QLabel("Ice Threshold:")
        ice_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        threshold_layout.addWidget(ice_label)

        self.ice_threshold_afda = QDoubleSpinBox()
        self.ice_threshold_afda.setRange(0, 1)
        self.ice_threshold_afda.setSingleStep(0.05)
        self.ice_threshold_afda.setValue(0.5)
        threshold_layout.addWidget(self.ice_threshold_afda)

        velocity_label = QLabel("Velocity Threshold:")
        velocity_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        threshold_layout.addWidget(velocity_label)

        self.velocity_threshold_afda = QDoubleSpinBox()
        self.velocity_threshold_afda.setRange(0, 100)
        self.velocity_threshold_afda.setSingleStep(0.1)
        self.velocity_threshold_afda.setValue(0.1)
        self.velocity_threshold_afda.setSuffix(" m/a")
        threshold_layout.addWidget(self.velocity_threshold_afda)

        param_layout.addRow("Cell Size:", threshold_layout)

        moving_window_layout = QHBoxLayout()
        moving_window_layout.setSpacing(5)

        self.use_window_check = QCheckBox()
        self.use_window_check.setChecked(False)
        self.use_window_check.toggled.connect(self.toggle_afda_window_options)
        moving_window_layout.addWidget(self.use_window_check)

        size_label = QLabel("Size:")
        size_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        moving_window_layout.addWidget(size_label)

        self.window_size_spin = QSpinBox()
        self.window_size_spin.setRange(1, 101)
        self.window_size_spin.setSingleStep(2)
        self.window_size_spin.setValue(9)
        self.window_size_spin.setEnabled(False)
        self.window_size_spin.setToolTip("Window size (odd number)")
        moving_window_layout.addWidget(self.window_size_spin)

        mask_label = QLabel("Accumulative:")
        mask_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        moving_window_layout.addWidget(mask_label)

        self.accumulative_ice_afda = QCheckBox()
        self.accumulative_ice_afda.setChecked(True)
        self.accumulative_ice_afda.setEnabled(False)
        self.accumulative_ice_afda.setToolTip(
            "If checked: ice present if ANY step in window has ice\n"
            "If unchecked: ice present if ALL steps have ice (consistent)"
        )
        moving_window_layout.addWidget(self.accumulative_ice_afda)

        param_layout.addRow("Enable Moving Time Window:", moving_window_layout)

        self.save_rasters_afda = QCheckBox()
        self.save_rasters_afda.setChecked(False)
        param_layout.addRow("Save time step rasters:", self.save_rasters_afda)

        param_group.setLayout(param_layout)
        layout.addWidget(param_group)

        info_text = QTextEdit()
        info_text.setReadOnly(True)
        info_text.setMaximumHeight(150)
        info_text.setText(
            "Enhanced Automated Flow Direction Analysis (AFDA) to compare modeled ice flow directions with field observations:\n"
            "  - Field flow direction is defined as the start to end point direction of each line\n"
            "  - Moving time window for smoothing U and V velocities\n"
            "  - Accumulative ice mask for the time window\n"
            "  - Seperate ice-free, frozen, and active ice flow areas\n"
            "  - Time series analysis of vector mean and variance of the flow direction agreement\n"
        )
        layout.addWidget(info_text)

        layout.addStretch()
        tab.setLayout(layout)
        return tab

    def create_overlap_tab(self):
        """Create Outline Overlap Analysis tab"""
        tab = QWidget()
        layout = QVBoxLayout()

        input_group = QGroupBox("Input Files")
        input_layout = QFormLayout()

        nc_layout = QHBoxLayout()
        self.nc_line_edit_overlap = QLineEdit()
        nc_button = QPushButton("Browse...")
        nc_button.clicked.connect(lambda: self.select_nc_file('overlap'))
        nc_layout.addWidget(self.nc_line_edit_overlap)
        nc_layout.addWidget(nc_button)
        input_layout.addRow("Modelled NetCDF File:", nc_layout)

        var_layout = QHBoxLayout()
        self.thk_var_combo_overlap = QComboBox()
        self.thk_var_combo_overlap.setEditable(True)
        self.thk_var_combo_overlap.setMinimumWidth(200)
        self.thk_var_combo_overlap.addItem("thk")
        self.thk_var_combo_overlap.addItem("land_ice_thickness")
        var_layout.addWidget(self.thk_var_combo_overlap)

        refresh_button = QPushButton("Refresh Variables")
        refresh_button.clicked.connect(lambda: self.refresh_variables('overlap'))
        var_layout.addWidget(refresh_button)
        input_layout.addRow("Ice Thickness Variable:", var_layout)

        shp_layout = QHBoxLayout()
        self.shp_line_edit_overlap = QLineEdit()
        shp_button = QPushButton("Browse...")
        shp_button.clicked.connect(lambda: self.select_shp_file('overlap'))
        shp_layout.addWidget(self.shp_line_edit_overlap)
        shp_layout.addWidget(shp_button)
        input_layout.addRow("Field Outline Polygon Shapefile:", shp_layout)

        id_layout = QHBoxLayout()
        self.id_field_combo_overlap = QComboBox()
        self.id_field_combo_overlap.setEnabled(False)
        id_layout.addWidget(self.id_field_combo_overlap)

        refresh_id_button = QPushButton("Refresh Fields")
        refresh_id_button.clicked.connect(lambda: self.refresh_shapefile_fields('overlap'))
        refresh_id_button.setEnabled(False)
        id_layout.addWidget(refresh_id_button)
        input_layout.addRow("Group by Field (ID):", id_layout)

        out_layout = QHBoxLayout()
        self.out_line_edit_overlap = QLineEdit()
        out_button = QPushButton("Browse...")
        out_button.clicked.connect(lambda: self.select_output_folder('overlap'))
        out_layout.addWidget(self.out_line_edit_overlap)
        out_layout.addWidget(out_button)
        input_layout.addRow("Output Folder:", out_layout)

        input_group.setLayout(input_layout)
        layout.addWidget(input_group)

        param_group = QGroupBox("Analysis Parameters")
        param_layout = QFormLayout()

        time_layout = QHBoxLayout()
        time_layout.setSpacing(5)

        self.start_spin_overlap = QSpinBox()
        self.start_spin_overlap.setRange(0, 9999)
        self.start_spin_overlap.setValue(0)
        time_layout.addWidget(self.start_spin_overlap)

        end_label = QLabel("End:")
        end_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        time_layout.addWidget(end_label)
        self.end_spin_overlap = QSpinBox()
        self.end_spin_overlap.setRange(0, 9999)
        self.end_spin_overlap.setValue(0)
        time_layout.addWidget(self.end_spin_overlap)

        step_label = QLabel("Step:")
        step_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        time_layout.addWidget(step_label)
        self.step_spin_overlap = QSpinBox()
        self.step_spin_overlap.setRange(1, 100)
        self.step_spin_overlap.setValue(1)
        time_layout.addWidget(self.step_spin_overlap)
        param_layout.addRow("Time Range Start:", time_layout)

        threshold_layout = QHBoxLayout()
        threshold_layout.setSpacing(5)

        self.cell_size_overlap = QDoubleSpinBox()
        self.cell_size_overlap.setRange(10, 10000)
        self.cell_size_overlap.setValue(500)
        self.cell_size_overlap.setSuffix(" m")
        threshold_layout.addWidget(self.cell_size_overlap)

        ice_label = QLabel("Min Ice Thickness:")
        ice_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        threshold_layout.addWidget(ice_label)

        self.min_thickness_overlap = QDoubleSpinBox()
        self.min_thickness_overlap.setRange(0, 100)
        self.min_thickness_overlap.setValue(1.0)
        self.min_thickness_overlap.setSuffix(" m")
        threshold_layout.addWidget(self.min_thickness_overlap)

        velocity_label = QLabel("Min Polygon Area:")
        velocity_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        threshold_layout.addWidget(velocity_label)

        self.min_polygon_area = QDoubleSpinBox()
        self.min_polygon_area.setRange(0, 100)
        self.min_polygon_area.setValue(0.01)
        self.min_polygon_area.setSuffix(" km²")
        threshold_layout.addWidget(self.min_polygon_area)

        param_layout.addRow("Cell Size:", threshold_layout)

        moving_window_layout = QHBoxLayout()
        moving_window_layout.setSpacing(5)

        self.use_window_overlap = QCheckBox()
        self.use_window_overlap.setChecked(False)
        self.use_window_overlap.toggled.connect(self.toggle_overlap_window_options)
        moving_window_layout.addWidget(self.use_window_overlap)

        size_label = QLabel("Size:")
        size_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        moving_window_layout.addWidget(size_label)

        self.window_size_overlap = QSpinBox()
        self.window_size_overlap.setRange(1, 101)
        self.window_size_overlap.setSingleStep(2)
        self.window_size_overlap.setValue(9)
        self.window_size_overlap.setEnabled(False)
        self.window_size_overlap.setToolTip("Window size (odd number)")
        moving_window_layout.addWidget(self.window_size_overlap)

        mask_label = QLabel("Accumulative:")
        mask_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        moving_window_layout.addWidget(mask_label)

        self.accumulative_ice_overlap = QCheckBox()
        self.accumulative_ice_overlap.setChecked(True)
        self.accumulative_ice_overlap.setEnabled(False)
        self.accumulative_ice_overlap.setToolTip(
            "If checked: ice present if ANY step in window has ice\n"
            "If unchecked: ice present if ALL steps have ice (consistent)"
        )
        moving_window_layout.addWidget(self.accumulative_ice_overlap)

        param_layout.addRow("Enable Moving Time Window:", moving_window_layout)

        save_layout = QHBoxLayout()
        save_layout.setSpacing(5)

        self.save_rasters_overlap = QCheckBox()
        self.save_rasters_overlap.setChecked(False)
        self.save_rasters_overlap.setToolTip("Save GeoTIFF rasters for each time step")
        save_layout.addWidget(self.save_rasters_overlap)

        save_plot_label = QLabel("Save time step plots:")
        save_plot_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        save_layout.addWidget(save_plot_label)

        self.save_plots_overlap = QCheckBox()
        self.save_plots_overlap.setChecked(True)
        self.save_plots_overlap.setToolTip("Save PNG plots for each time step")
        save_layout.addWidget(self.save_plots_overlap)

        param_layout.addRow("Save time step plots:", save_layout)

        param_group.setLayout(param_layout)
        layout.addWidget(param_group)

        info_text = QTextEdit()
        info_text.setReadOnly(True)
        info_text.setMaximumHeight(150)
        info_text.setText(
            "Raster-based Overlap Analysis with field-mapped polygon outlines as ground truth (Precision/Recall/F1-Score):\n"
            "  - True Positive (TP): Ice correctly predicted (model & field both have ice)\n"
            "  - False Positive (FP): Ice incorrectly predicted (model has ice, field does not)\n"
            "  - False Negative (FN): Ice missed (field has ice, model does not)\n"
            "Metrics:\n"
            "  - Precision = TP / (TP + FP)  (how many predicted ice cells are correct)\n"
            "  - Recall = TP / (TP + FN)     (how many actual ice cells were captured)\n"
            "  - F1-Score = 2 * (Precision * Recall) / (Precision + Recall)\n"
            "Best match time step is the one with the highest F1-Score."
        )
        layout.addWidget(info_text)

        layout.addStretch()
        tab.setLayout(layout)
        return tab

    def create_polygon_overlap_tab(self):
        """Create Polygon-Based Outline Overlap Analysis tab"""
        tab = QWidget()
        layout = QVBoxLayout()

        input_group = QGroupBox("Input Files")
        input_layout = QFormLayout()

        nc_layout = QHBoxLayout()
        self.nc_line_edit_polygon = QLineEdit()
        nc_button = QPushButton("Browse...")
        nc_button.clicked.connect(lambda: self.select_nc_file('polygon'))
        nc_layout.addWidget(self.nc_line_edit_polygon)
        nc_layout.addWidget(nc_button)
        input_layout.addRow("Modelled NetCDF File:", nc_layout)

        var_layout = QHBoxLayout()
        self.thk_var_combo_polygon = QComboBox()
        self.thk_var_combo_polygon.setEditable(True)
        self.thk_var_combo_polygon.setMinimumWidth(200)
        self.thk_var_combo_polygon.addItem("thk")
        self.thk_var_combo_polygon.addItem("land_ice_thickness")
        var_layout.addWidget(self.thk_var_combo_polygon)

        refresh_button = QPushButton("Refresh Variables")
        refresh_button.clicked.connect(lambda: self.refresh_variables('polygon'))
        var_layout.addWidget(refresh_button)
        input_layout.addRow("Ice Thickness Variable:", var_layout)

        shp_layout = QHBoxLayout()
        self.shp_line_edit_polygon = QLineEdit()
        shp_button = QPushButton("Browse...")
        shp_button.clicked.connect(lambda: self.select_shp_file('polygon'))
        shp_layout.addWidget(self.shp_line_edit_polygon)
        shp_layout.addWidget(shp_button)
        input_layout.addRow("Field Outline Polygon Shapefile:", shp_layout)

        id_layout = QHBoxLayout()
        self.id_field_combo_polygon = QComboBox()
        self.id_field_combo_polygon.setEnabled(False)
        id_layout.addWidget(self.id_field_combo_polygon)

        refresh_id_button = QPushButton("Refresh Fields")
        refresh_id_button.clicked.connect(lambda: self.refresh_shapefile_fields('polygon'))
        refresh_id_button.setEnabled(False)
        id_layout.addWidget(refresh_id_button)
        input_layout.addRow("Group by Field (ID):", id_layout)

        out_layout = QHBoxLayout()
        self.out_line_edit_polygon = QLineEdit()
        out_button = QPushButton("Browse...")
        out_button.clicked.connect(lambda: self.select_output_folder('polygon'))
        out_layout.addWidget(self.out_line_edit_polygon)
        out_layout.addWidget(out_button)
        input_layout.addRow("Output Folder:", out_layout)

        input_group.setLayout(input_layout)
        layout.addWidget(input_group)

        param_group = QGroupBox("Analysis Parameters")
        param_layout = QFormLayout()

        time_layout = QHBoxLayout()
        time_layout.setSpacing(5)

        self.start_spin_polygon = QSpinBox()
        self.start_spin_polygon.setRange(0, 9999)
        self.start_spin_polygon.setValue(0)
        time_layout.addWidget(self.start_spin_polygon)

        end_label = QLabel("End:")
        end_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        time_layout.addWidget(end_label)
        self.end_spin_polygon = QSpinBox()
        self.end_spin_polygon.setRange(0, 9999)
        self.end_spin_polygon.setValue(0)
        time_layout.addWidget(self.end_spin_polygon)

        step_label = QLabel("Step:")
        step_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        time_layout.addWidget(step_label)
        self.step_spin_polygon = QSpinBox()
        self.step_spin_polygon.setRange(1, 100)
        self.step_spin_polygon.setValue(1)
        time_layout.addWidget(self.step_spin_polygon)
        param_layout.addRow("Time Range Start:", time_layout)

        moving_window_layout = QHBoxLayout()
        moving_window_layout.setSpacing(5)

        self.use_window_polygon = QCheckBox()
        self.use_window_polygon.setChecked(False)
        self.use_window_polygon.toggled.connect(self.toggle_polygon_window_options)
        moving_window_layout.addWidget(self.use_window_polygon)

        size_label = QLabel("Size:")
        size_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        moving_window_layout.addWidget(size_label)

        self.window_size_polygon = QSpinBox()
        self.window_size_polygon.setRange(1, 101)
        self.window_size_polygon.setSingleStep(2)
        self.window_size_polygon.setValue(9)
        self.window_size_polygon.setEnabled(False)
        self.window_size_polygon.setToolTip("Window size (odd number)")
        moving_window_layout.addWidget(self.window_size_polygon)

        mask_label = QLabel("Accumulative:")
        mask_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        moving_window_layout.addWidget(mask_label)

        self.accumulative_ice_polygon = QCheckBox()
        self.accumulative_ice_polygon.setChecked(True)
        self.accumulative_ice_polygon.setEnabled(False)
        self.accumulative_ice_polygon.setToolTip(
            "If checked: ice present if ANY step in window has ice\n"
            "If unchecked: ice present if ALL steps have ice (consistent)"
        )
        moving_window_layout.addWidget(self.accumulative_ice_polygon)

        param_layout.addRow("Enable Moving Time Window:", moving_window_layout)

        threshold_layout = QHBoxLayout()
        threshold_layout.setSpacing(5)

        self.min_thickness_polygon = QDoubleSpinBox()
        self.min_thickness_polygon.setRange(0, 100)
        self.min_thickness_polygon.setValue(1.0)
        self.min_thickness_polygon.setSuffix(" m")
        threshold_layout.addWidget(self.min_thickness_polygon)

        velocity_label = QLabel("Min Polygon Area:")
        velocity_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        threshold_layout.addWidget(velocity_label)

        self.min_polygon_area = QDoubleSpinBox()
        self.min_polygon_area.setRange(0, 100)
        self.min_polygon_area.setValue(0.01)
        self.min_polygon_area.setSuffix(" km²")
        self.min_polygon_area.setToolTip("Minimum area of ice polygons to consider (filters out noise)")
        threshold_layout.addWidget(self.min_polygon_area)

        param_layout.addRow("Min Ice Thickness:", threshold_layout)

        save_layout = QHBoxLayout()
        save_layout.setSpacing(5)

        self.save_shapefiles_polygon = QCheckBox()
        self.save_shapefiles_polygon.setChecked(False)
        self.save_shapefiles_polygon.setToolTip("Save model ice polygons as shapefiles for each time step")
        save_layout.addWidget(self.save_shapefiles_polygon)

        save_plot_label = QLabel("Save time step plots:")
        save_plot_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        save_layout.addWidget(save_plot_label)

        self.save_plots_polygon = QCheckBox()
        self.save_plots_polygon.setChecked(True)
        self.save_plots_polygon.setToolTip("Save PNG plots for each time step")
        save_layout.addWidget(self.save_plots_polygon)

        param_layout.addRow("Save time step shapefiles:", save_layout)

        param_group.setLayout(param_layout)
        layout.addWidget(param_group)

        info_text = QTextEdit()
        info_text.setReadOnly(True)
        info_text.setMaximumHeight(150)
        info_text.setText(
            "Vector-based Polygon Overlap Analysis (Precision/Recall/F1-Score/IoU):\n"
            "  - Converts model ice masks to polygons\n"
            "  - Uses geometric overlay (intersection, difference) for metrics\n"
            "Metrics:\n"
            "  - Precision = TP / (TP + FP)  (how many predicted ice cells are correct)\n"
            "  - Recall = TP / (TP + FN)     (how many actual ice cells were captured)\n"
            "  - F1-Score = 2 * (Precision * Recall) / (Precision + Recall)\n"
            "  - IoU (Jaccard Index) = TP / (TP + FP + FN)\n"
            "Best match time step is the one with the highest F1-Score/IoU. "
            "Note: Small polygons below Min Polygon Area are filtered out as noise."
        )
        layout.addWidget(info_text)

        layout.addStretch()
        tab.setLayout(layout)
        return tab

    def create_point_compare_tab(self):
        """Create Point-Based Elevation/Thickness Comparison tab"""
        tab = QWidget()
        layout = QVBoxLayout()

        input_group = QGroupBox("Input Files")
        input_layout = QFormLayout()

        nc_layout = QHBoxLayout()
        self.nc_line_edit_point = QLineEdit()
        nc_button = QPushButton("Browse...")
        nc_button.clicked.connect(lambda: self.select_nc_file('point'))
        nc_layout.addWidget(self.nc_line_edit_point)
        nc_layout.addWidget(nc_button)
        input_layout.addRow("Modelled NetCDF File:", nc_layout)

        var_layout = QHBoxLayout()
        self.var_combo_point = QComboBox()
        self.var_combo_point.setEditable(True)
        self.var_combo_point.setMinimumWidth(200)
        self.var_combo_point.addItem("thk")
        self.var_combo_point.addItem("topo")
        self.var_combo_point.addItem("land_ice_thickness")
        self.var_combo_point.addItem("surface_altitude")
        var_layout.addWidget(self.var_combo_point)

        refresh_button = QPushButton("Refresh Variables")
        refresh_button.clicked.connect(lambda: self.refresh_variables('point'))
        var_layout.addWidget(refresh_button)
        input_layout.addRow("Elevation/Thickness Variable:", var_layout)

        shp_layout = QHBoxLayout()
        self.shp_line_edit_point = QLineEdit()
        shp_button = QPushButton("Browse...")
        shp_button.clicked.connect(lambda: self.select_shp_file('point'))
        shp_layout.addWidget(self.shp_line_edit_point)
        shp_layout.addWidget(shp_button)
        input_layout.addRow("Field Elevation/Thickness Points:", shp_layout)

        value_layout = QHBoxLayout()

        self.id_field_combo_point = QComboBox()
        self.id_field_combo_point.setEnabled(False)
        self.id_field_combo_point.setToolTip("Select the field for group analysis")
        value_layout.addWidget(self.id_field_combo_point)

        id_label = QLabel("Elevation/Thickness Field:")
        id_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        value_layout.addWidget(id_label)

        self.value_field_combo_point = QComboBox()
        self.value_field_combo_point.setEnabled(False)
        self.value_field_combo_point.setToolTip("Select the field containing observed elevation/thickness values")
        value_layout.addWidget(self.value_field_combo_point)

        refresh_id_button = QPushButton("Refresh Fields")
        refresh_id_button.clicked.connect(lambda: self.refresh_shapefile_fields('point'))
        refresh_id_button.setEnabled(False)
        value_layout.addWidget(refresh_id_button)

        input_layout.addRow("Group by Field (ID):", value_layout)

        out_layout = QHBoxLayout()
        self.out_line_edit_point = QLineEdit()
        out_button = QPushButton("Browse...")
        out_button.clicked.connect(lambda: self.select_output_folder('point'))
        out_layout.addWidget(self.out_line_edit_point)
        out_layout.addWidget(out_button)
        input_layout.addRow("Output Folder:", out_layout)

        input_group.setLayout(input_layout)
        layout.addWidget(input_group)

        param_group = QGroupBox("Analysis Parameters")
        param_layout = QFormLayout()

        time_layout = QHBoxLayout()
        time_layout.setSpacing(5)

        self.start_spin_point = QSpinBox()
        self.start_spin_point.setRange(0, 9999)
        self.start_spin_point.setValue(0)
        time_layout.addWidget(self.start_spin_point)

        end_label = QLabel("End:")
        end_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        time_layout.addWidget(end_label)
        self.end_spin_point = QSpinBox()
        self.end_spin_point.setRange(0, 9999)
        self.end_spin_point.setValue(0)
        time_layout.addWidget(self.end_spin_point)

        step_label = QLabel("Step:")
        step_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        time_layout.addWidget(step_label)
        self.step_spin_point = QSpinBox()
        self.step_spin_point.setRange(1, 100)
        self.step_spin_point.setValue(1)
        time_layout.addWidget(self.step_spin_point)
        param_layout.addRow("Time Range Start:", time_layout)

        thickness_layout = QHBoxLayout()
        thickness_layout.setSpacing(5)

        self.thick_var_combo_point = QComboBox()
        self.thick_var_combo_point.setEditable(True)
        self.thick_var_combo_point.addItem("thk")
        self.thick_var_combo_point.addItem("land_ice_thickness")
        self.thick_var_combo_point.addItem("ice_thickness")
        thickness_layout.addWidget(self.thick_var_combo_point)

        min_thickness_label = QLabel("Min Ice Thickness:")
        min_thickness_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        thickness_layout.addWidget(min_thickness_label)

        self.min_thickness_point = QDoubleSpinBox()
        self.min_thickness_point.setRange(0, 100)
        self.min_thickness_point.setValue(1.0)
        self.min_thickness_point.setSuffix(" m")
        self.min_thickness_point.setToolTip("Minimum ice thickness to consider a point as ice-covered")
        thickness_layout.addWidget(self.min_thickness_point)

        param_layout.addRow("Thickness Field:", thickness_layout)

        moving_window_layout = QHBoxLayout()
        moving_window_layout.setSpacing(5)

        self.use_window_point = QCheckBox()
        self.use_window_point.setChecked(False)
        self.use_window_point.toggled.connect(self.toggle_point_window_options)
        moving_window_layout.addWidget(self.use_window_point)

        size_label = QLabel("Size:")
        size_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        moving_window_layout.addWidget(size_label)

        self.window_size_point = QSpinBox()
        self.window_size_point.setRange(1, 101)
        self.window_size_point.setSingleStep(2)
        self.window_size_point.setValue(9)
        self.window_size_point.setEnabled(False)
        self.window_size_point.setToolTip("Window size (odd number)")
        moving_window_layout.addWidget(self.window_size_point)

        mask_label = QLabel("Accumulative:")
        mask_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        moving_window_layout.addWidget(mask_label)

        self.accumulative_point = QCheckBox()
        self.accumulative_point.setChecked(True)
        self.accumulative_point.setEnabled(False)
        self.accumulative_point.setToolTip(
            "If checked: ice present if ANY step in window has ice\n"
            "If unchecked: ice present if ALL steps have ice (consistent)"
        )
        moving_window_layout.addWidget(self.accumulative_point)

        param_layout.addRow("Enable Moving Time Window:", moving_window_layout)

        save_layout = QHBoxLayout()
        self.save_plots_point = QCheckBox()
        self.save_plots_point.setChecked(True)
        self.save_plots_point.setToolTip("Save individual time step scatter plots")
        save_layout.addWidget(self.save_plots_point)
        save_layout.addStretch()
        param_layout.addRow("Save time step plots:", save_layout)

        param_group.setLayout(param_layout)
        layout.addWidget(param_group)

        info_text = QTextEdit()
        info_text.setReadOnly(True)
        info_text.setMaximumHeight(200)
        info_text.setText(
            "Point-based Elevation/Thickness Comparison of modeled ice surface elevation (or thickness) with field observation points.\n"
            "Input requirements:\n"
            "  - Input Shapefile must contain point geometries and a numeric column with observed values (e.g., 'elevation', 'thickness', or 'value')\n"
            "Statistics calculated:\n"
            "  - RMSE (Root Mean Square Error) - used for best match selection\n"
            "  - Mean difference, Standard deviation, Min, Max\n"
            "  - MAE (Mean Absolute Error)\n"
            "  - R² (Coefficient of Determination)\n"
            "Outputs:\n"
            "  - Time series of all statistics\n"
            "  - Scatter plot of modeled vs observed at best match\n"
            "  - Best match summary with minimum RMSE"
        )
        layout.addWidget(info_text)

        layout.addStretch()
        tab.setLayout(layout)
        return tab

    def create_raster_to_nc_tab(self):
        """Create TIFF/ASC to NetCDF Converter tab (No Resampling)"""
        tab = QWidget()
        layout = QVBoxLayout()

        input_group = QGroupBox("Input Files")
        input_layout = QFormLayout()

        thick_layout = QHBoxLayout()
        self.thick_folder_line_edit = QLineEdit()
        thick_button = QPushButton("Browse...")
        thick_button.clicked.connect(lambda: self.select_folder('thick'))
        thick_layout.addWidget(self.thick_folder_line_edit)
        thick_layout.addWidget(thick_button)
        input_layout.addRow("Thickness Folder (required):", thick_layout)

        surface_layout = QHBoxLayout()
        self.surface_folder_line_edit = QLineEdit()
        surface_button = QPushButton("Browse...")
        surface_button.clicked.connect(lambda: self.select_folder('surface'))
        surface_layout.addWidget(self.surface_folder_line_edit)
        surface_layout.addWidget(surface_button)
        input_layout.addRow("Surface Elevation Folder (optional):", surface_layout)

        uvel_layout = QHBoxLayout()
        self.uvel_folder_line_edit = QLineEdit()
        uvel_button = QPushButton("Browse...")
        uvel_button.clicked.connect(lambda: self.select_folder('uvel'))
        uvel_layout.addWidget(self.uvel_folder_line_edit)
        uvel_layout.addWidget(uvel_button)
        input_layout.addRow("U-Velocity Folder (optional):", uvel_layout)

        vvel_layout = QHBoxLayout()
        self.vvel_folder_line_edit = QLineEdit()
        vvel_button = QPushButton("Browse...")
        vvel_button.clicked.connect(lambda: self.select_folder('vvel'))
        vvel_layout.addWidget(self.vvel_folder_line_edit)
        vvel_layout.addWidget(vvel_button)
        input_layout.addRow("V-Velocity Folder (optional):", vvel_layout)

        output_layout = QHBoxLayout()
        self.output_nc_line_edit = QLineEdit()
        output_button = QPushButton("Browse...")
        output_button.clicked.connect(self.select_output_nc_file)
        output_layout.addWidget(self.output_nc_line_edit)
        output_layout.addWidget(output_button)
        input_layout.addRow("Output NetCDF File:", output_layout)

        input_group.setLayout(input_layout)
        layout.addWidget(input_group)

        param_group = QGroupBox("Conversion Parameters")
        param_layout = QFormLayout()

        time_range_layout = QHBoxLayout()
        self.convert_start_spin = QSpinBox()
        self.convert_start_spin.setRange(0, 9999)
        self.convert_start_spin.setValue(0)
        time_range_layout.addWidget(self.convert_start_spin)

        self.convert_end_spin = QSpinBox()
        self.convert_end_spin.setRange(0, 9999)
        self.convert_end_spin.setValue(100)
        time_range_layout.addWidget(self.convert_end_spin)

        self.convert_step_spin = QSpinBox()
        self.convert_step_spin.setRange(1, 100)
        self.convert_step_spin.setValue(1)
        time_range_layout.addWidget(self.convert_step_spin)
        param_layout.addRow("Time Range (Start, End, Step):", time_range_layout)

        self.use_compression = QCheckBox()
        self.use_compression.setChecked(True)
        param_layout.addRow("Enable NetCDF Compression:", self.use_compression)

        param_group.setLayout(param_layout)
        layout.addWidget(param_group)

        info_text = QTextEdit()
        info_text.setReadOnly(True)
        info_text.setMaximumHeight(350)
        info_text.setText(
            "TIFF/ASC to NetCDF CONVERTER:\n"
            "This tool converts individual GeoTIFF or ASCII Grid files into a single NetCDF file.\n"
            "IMPORTANT: Original resolution and crs are preserved - NO RESAMPLING is performed.\n"
            "Folder Structure:\n"
            "  - Each folder should contain files for one variable\n"
            "  - Files should contain time indices in their names (e.g., thk_0010.tif)\n"
            "  - All files must have the same spatial extent and resolution\n"
            "Supported Variables:\n"
            "  - Thickness: Required for ice mask detection\n"
            "  - Surface Elevation: Optional, for point comparison\n"
            "  - U/V Velocity: Optional, for flow direction analysis\n"
            "Output:\n"
            "  - Single NetCDF file with original resolution and crs ready to use with GLIMAT's tools"
        )
        layout.addWidget(info_text)

        layout.addStretch()
        tab.setLayout(layout)
        return tab

    def create_lala_tab(self):
        """Create LALA tab widgets with variable selection"""
        tab = QWidget()
        layout = QVBoxLayout()

        input_group = QGroupBox("Input Files")
        input_layout = QFormLayout()

        nc_layout = QHBoxLayout()
        self.nc_line_edit_lala = QLineEdit()
        nc_button = QPushButton("Browse...")
        nc_button.clicked.connect(lambda: self.select_nc_file('lala'))
        nc_layout.addWidget(self.nc_line_edit_lala)
        nc_layout.addWidget(nc_button)
        input_layout.addRow("Modelled NetCDF File:", nc_layout)

        var_group = QGroupBox("Variable Selection")
        var_layout = QFormLayout()

        u_layout = QHBoxLayout()
        self.u_var_combo = QComboBox()
        self.u_var_combo.setEditable(True)
        self.u_var_combo.setMinimumWidth(200)
        self.u_var_combo.addItem("uvelbase")
        self.u_var_combo.addItem("uvelsurf")
        self.u_var_combo.addItem("uvel")
        self.u_var_combo.addItem("ubar")
        u_layout.addWidget(self.u_var_combo)
        var_layout.addRow("U-Velocity Variable:", u_layout)

        v_layout = QHBoxLayout()
        self.v_var_combo = QComboBox()
        self.v_var_combo.setEditable(True)
        self.v_var_combo.setMinimumWidth(200)
        self.v_var_combo.addItem("vvelsurf")
        self.v_var_combo.addItem("vvelbase")
        self.v_var_combo.addItem("vvel")
        self.v_var_combo.addItem("vbar")
        v_layout.addWidget(self.v_var_combo)
        var_layout.addRow("V-Velocity Variable:", v_layout)

        thk_layout = QHBoxLayout()
        self.thk_var_combo = QComboBox()
        self.thk_var_combo.setEditable(True)
        self.thk_var_combo.setMinimumWidth(200)
        self.thk_var_combo.addItem("thk")
        self.thk_var_combo.addItem("land_ice_thickness")
        thk_layout.addWidget(self.thk_var_combo)
        var_layout.addRow("Thickness Variable:", thk_layout)

        mask_layout = QHBoxLayout()
        self.mask_var_combo = QComboBox()
        self.mask_var_combo.setEditable(True)
        self.mask_var_combo.setMinimumWidth(200)
        self.mask_var_combo.addItem("mask")
        mask_layout.addWidget(self.mask_var_combo)
        var_layout.addRow("Mask Variable:", mask_layout)

        refresh_button = QPushButton("Refresh Variables from NetCDF")
        refresh_button.clicked.connect(lambda: self.refresh_variables('lala'))
        var_layout.addRow("", refresh_button)

        var_group.setLayout(var_layout)
        input_layout.addRow("", var_group)

        shp_layout = QHBoxLayout()
        self.shp_line_edit_lala = QLineEdit()
        shp_button = QPushButton("Browse...")
        shp_button.clicked.connect(lambda: self.select_shp_file('lala'))
        shp_layout.addWidget(self.shp_line_edit_lala)
        shp_layout.addWidget(shp_button)
        input_layout.addRow("Flow Lineations Shapefile:", shp_layout)

        out_layout = QHBoxLayout()
        self.out_line_edit_lala = QLineEdit()
        out_button = QPushButton("Browse...")
        out_button.clicked.connect(lambda: self.select_output_folder('lala'))
        out_layout.addWidget(self.out_line_edit_lala)
        out_layout.addWidget(out_button)
        input_layout.addRow("Output Folder:", out_layout)

        input_group.setLayout(input_layout)
        layout.addWidget(input_group)

        param_group = QGroupBox("Analysis Parameters")
        param_layout = QFormLayout()

        threshold_layout = QHBoxLayout()
        threshold_layout.setSpacing(5)

        self.thk_threshold_lala = QDoubleSpinBox()
        self.thk_threshold_lala.setRange(0, 100)
        self.thk_threshold_lala.setSingleStep(0.5)
        self.thk_threshold_lala.setValue(1.0)
        self.thk_threshold_lala.setSuffix(" m/a")
        threshold_layout.addWidget(self.thk_threshold_lala)

        velocity_label = QLabel("Velocity Threshold:")
        velocity_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        threshold_layout.addWidget(velocity_label)

        self.velocity_threshold_lala = QDoubleSpinBox()
        self.velocity_threshold_lala.setRange(0, 100)
        self.velocity_threshold_lala.setSingleStep(0.1)
        self.velocity_threshold_lala.setValue(1)
        self.velocity_threshold_lala.setSuffix(" m/a")
        threshold_layout.addWidget(self.velocity_threshold_lala)

        mask_label = QLabel("Grounded Ice Code:")
        mask_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        threshold_layout.addWidget(mask_label)

        self.mask_threshold_combo_lala = QComboBox()
        self.mask_threshold_combo_lala.setEditable(True)
        self.mask_threshold_combo_lala.addItem("2")
        self.mask_threshold_combo_lala.addItem("0")
        threshold_layout.addWidget(self.mask_threshold_combo_lala)

        param_layout.addRow("Thickness Threshold:", threshold_layout)

        kappa_p_layout = QHBoxLayout()
        kappa_p_layout.setSpacing(5)

        self.kappa_spin_lala = QDoubleSpinBox()
        self.kappa_spin_lala.setRange(0, 100)
        self.kappa_spin_lala.setSingleStep(1)
        self.kappa_spin_lala.setValue(10)
        kappa_p_layout.addWidget(self.kappa_spin_lala)

        p_value_label = QLabel("p value:")
        p_value_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        kappa_p_layout.addWidget(p_value_label)

        self.p_value_lala = QDoubleSpinBox()
        self.p_value_lala.setRange(0, 1)
        self.p_value_lala.setSingleStep(0.01)
        self.p_value_lala.setValue(0.01)
        kappa_p_layout.addWidget(self.p_value_lala)

        param_layout.addRow("Kappa Value:", kappa_p_layout)

        spacing_value_label = QLabel("")
        spacing_value_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        kappa_p_layout.addWidget(spacing_value_label)

        spacing_value_label = QLabel("")
        spacing_value_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        kappa_p_layout.addWidget(spacing_value_label)

        param_group.setLayout(param_layout)
        layout.addWidget(param_group)

        info_text = QTextEdit()
        info_text.setReadOnly(True)
        info_text.setMaximumHeight(150)
        info_text.setText(
            "The Likelihood of Accordant Lineations Analysis (LALA):\n"
            "  - LALA provides a statistically rigorous measure of the log-likelihood of a supplied simulation through comparison of\n"
            "    simulation output with both the location and direction of observed lineations\n"
            "  - Revised based on Archer et al.(2023). Assessing ice sheet models against the landform record: The Likelihood of Accordant:\n"
            "    Lineations Analysis (LALA) tool. Earth Surface Processes and Landforms 48, 2754-2771. https://doi.org/10.1002/esp.5658 \n"
            "  - Field flow direction is defined as the start to end point direction of each line\n"
        )
        layout.addWidget(info_text)

        layout.addStretch()
        tab.setLayout(layout)
        return tab

    def select_folder(self, var_type):
        """Select folder containing TIFF files"""
        folder_path = QFileDialog.getExistingDirectory(self, f"Select {var_type.upper()} TIFF Folder")
        if folder_path:
            if var_type == 'thick':
                self.thick_folder_line_edit.setText(folder_path)
                self.append_console(f"Selected thickness folder: {folder_path}")
                self.detect_time_range_from_folder(folder_path)
            elif var_type == 'surface':
                self.surface_folder_line_edit.setText(folder_path)
                self.append_console(f"Selected surface elevation folder: {folder_path}")
            elif var_type == 'uvel':
                self.uvel_folder_line_edit.setText(folder_path)
                self.append_console(f"Selected U-velocity folder: {folder_path}")
            elif var_type == 'vvel':
                self.vvel_folder_line_edit.setText(folder_path)
                self.append_console(f"Selected V-velocity folder: {folder_path}")

    def refresh_variables(self, tab_name):
        """Refresh variable lists from the selected NetCDF file"""
        if tab_name == 'apca':
            nc_file = self.nc_line_edit_apca.text()
            if nc_file:
                self.load_netcdf_variables(nc_file, 'apca')
            else:
                QMessageBox.warning(self, "No File", "Please select a NetCDF file first.")
        elif tab_name == 'afda':
            nc_file = self.nc_line_edit_afda.text()
            if nc_file:
                self.load_netcdf_variables(nc_file, 'afda')
            else:
                QMessageBox.warning(self, "No File", "Please select a NetCDF file first.")
        elif tab_name == 'lala':
            nc_file = self.nc_line_edit_lala.text()
            if nc_file:
                self.load_netcdf_variables(nc_file, 'lala')
            else:
                QMessageBox.warning(self, "No File", "Please select a NetCDF file first.")
        elif tab_name == 'overlap':
            nc_file = self.nc_line_edit_overlap.text()
            if nc_file:
                self.load_netcdf_variables(nc_file, 'overlap')
            else:
                QMessageBox.warning(self, "No File", "Please select a NetCDF file first.")
        elif tab_name == 'polygon':
            nc_file = self.nc_line_edit_polygon.text()
            if nc_file:
                self.load_netcdf_variables(nc_file, 'polygon')
            else:
                QMessageBox.warning(self, "No File", "Please select a NetCDF file first.")
        else:
            nc_file = self.nc_line_edit_point.text()
            if nc_file:
                self.load_netcdf_variables(nc_file, 'point')
            else:
                QMessageBox.warning(self, "No File", "Please select a NetCDF file first.")

    def select_nc_file(self, tab_name):
        """Select NetCDF file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Model Output NetCDF File", "", "NetCDF Files (*.nc);;All Files (*)"
        )

        if file_path:
            if tab_name == 'apca':
                self.nc_line_edit_apca.setText(file_path)
                self.append_console(f"Selected NetCDF: {file_path}")
                self.load_netcdf_variables(file_path, 'apca')
                self.update_end_time_from_netcdf(file_path, 'apca')
            elif tab_name == 'afda':
                self.nc_line_edit_afda.setText(file_path)
                self.append_console(f"Selected NetCDF: {file_path}")
                self.load_netcdf_variables(file_path, 'afda')
                self.update_end_time_from_netcdf(file_path, 'afda')
            elif tab_name == 'lala':
                self.nc_line_edit_lala.setText(file_path)
                self.append_console(f"Selected NetCDF: {file_path}")
                self.load_netcdf_variables(file_path, 'lala')
            elif tab_name == 'overlap':
                self.nc_line_edit_overlap.setText(file_path)
                self.append_console(f"Selected NetCDF: {file_path}")
                self.load_netcdf_variables(file_path, 'overlap')
                self.update_end_time_from_netcdf(file_path, 'overlap')
            elif tab_name == 'polygon':
                self.nc_line_edit_polygon.setText(file_path)
                self.append_console(f"Selected NetCDF: {file_path}")
                self.load_netcdf_variables(file_path, 'polygon')
                self.update_end_time_from_netcdf(file_path, 'polygon')
            else:
                self.nc_line_edit_point.setText(file_path)
                self.append_console(f"Selected NetCDF: {file_path}")
                self.load_netcdf_variables(file_path, 'point')
                self.update_end_time_from_netcdf(file_path, 'point')

    def select_shp_file(self, tab_name):
        """Select shapefile and auto-populate ID fields"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Shapefile", "", "Shapefile (*.shp);;All Files (*)"
        )
        if file_path:
            if tab_name == 'apca':
                self.shp_line_edit_apca.setText(file_path)
                self.append_console(f"Selected Shapefile: {file_path}")
                self.populate_shapefile_fields(file_path, 'apca')
            elif tab_name == 'afda':
                self.shp_line_edit_afda.setText(file_path)
                self.append_console(f"Selected Shapefile: {file_path}")
            elif tab_name == 'lala':
                self.shp_line_edit_lala.setText(file_path)
                self.append_console(f"Selected Shapefile: {file_path}")
            elif tab_name == 'overlap':
                self.shp_line_edit_overlap.setText(file_path)
                self.append_console(f"Selected Shapefile: {file_path}")
                self.populate_shapefile_fields(file_path, 'overlap')
            elif tab_name == 'polygon':
                self.shp_line_edit_polygon.setText(file_path)
                self.append_console(f"Selected Shapefile: {file_path}")
                self.populate_shapefile_fields(file_path, 'polygon')
            else:
                self.shp_line_edit_point.setText(file_path)
                self.append_console(f"Selected Shapefile: {file_path}")
                self.populate_shapefile_fields(file_path, 'point')

    def populate_shapefile_fields(self, shapefile_path, tab_name):
        """Read shapefile and populate ID field combo boxes"""
        try:
            import geopandas as gpd
            gdf = gpd.read_file(shapefile_path, engine="pyogrio")
            fields = list(gdf.columns)

            exclude_fields = ['geometry', 'Shape_Length', 'Shape_Area']
            id_candidates = [f for f in fields if f.lower() not in [x.lower() for x in exclude_fields]]

            priority_names = ['id', 'ID', 'glacier_id', 'GlacierID', 'GLAC_ID', 'Id', 'poly_id', 'POLY_ID']
            priority_fields = []
            other_fields = []

            for field in id_candidates:
                if field.lower() in [p.lower() for p in priority_names]:
                    priority_fields.append(field)
                else:
                    other_fields.append(field)

            sorted_fields = priority_fields + sorted(other_fields)

            if tab_name == 'apca':
                self.id_field_combo.clear()
                self.id_field_combo.addItem("-- Do not group (analyze all together) --")
                for field in sorted_fields:
                    self.id_field_combo.addItem(field)
                self.id_field_combo.setEnabled(True)
                self.append_console(f"  Found {len(sorted_fields)} ID field candidates: {sorted_fields[:5]}...")

                for button in self.findChildren(QPushButton):
                    if button.text() == "Refresh Fields":
                        button.setEnabled(True)

            elif tab_name == 'afda':
                self.id_field_combo_afda.clear()
                self.id_field_combo_afda.addItem("-- Do not group (analyze all together) --")
                for field in sorted_fields:
                    self.id_field_combo_afda.addItem(field)
                self.id_field_combo_afda.setEnabled(True)
                self.append_console(f"  Found {len(sorted_fields)} ID field candidates: {sorted_fields[:5]}...")

                for button in self.findChildren(QPushButton):
                    if button.text() == "Refresh Fields":
                        button.setEnabled(True)

            elif tab_name == 'overlap':
                self.id_field_combo_overlap.clear()
                self.id_field_combo_overlap.addItem("-- Do not group (analyze all together) --")
                for field in sorted_fields:
                    self.id_field_combo_overlap.addItem(field)
                self.id_field_combo_overlap.setEnabled(True)
                self.append_console(f"  Found {len(sorted_fields)} ID field candidates: {sorted_fields[:5]}...")

                for button in self.findChildren(QPushButton):
                    if button.text() == "Refresh Fields":
                        button.setEnabled(True)

            elif tab_name == 'polygon':
                self.id_field_combo_polygon.clear()
                self.id_field_combo_polygon.addItem("-- Do not group (analyze all together) --")
                for field in sorted_fields:
                    self.id_field_combo_polygon.addItem(field)
                self.id_field_combo_polygon.setEnabled(True)
                self.append_console(f"  Found {len(sorted_fields)} ID field candidates: {sorted_fields[:5]}...")

                for button in self.findChildren(QPushButton):
                    if button.text() == "Refresh Fields":
                        button.setEnabled(True)
            else:
                self.id_field_combo_point.clear()
                self.id_field_combo_point.addItem("-- Do not group (analyze all together) --")
                self.value_field_combo_point.clear()
                for field in sorted_fields:
                    self.id_field_combo_point.addItem(field)
                    self.value_field_combo_point.addItem(field)
                self.id_field_combo_point.setEnabled(True)
                self.value_field_combo_point.setEnabled(True)
                self.append_console(f"  Found {len(sorted_fields)} ID field candidates: {sorted_fields[:5]}...")
                self.append_console(f"  Found {len(sorted_fields)} Elevation/Thickness field candidates: {sorted_fields[:5]}...")

                for button in self.findChildren(QPushButton):
                    if button.text() == "Refresh Fields":
                        button.setEnabled(True)

        except Exception as e:
            self.append_console(f"Error reading shapefile fields: {str(e)}")

    def refresh_shapefile_fields(self, tab_name):
        """Manually refresh shapefile fields"""
        if tab_name == 'apca':
            shapefile_path = self.shp_line_edit_apca.text()
            if shapefile_path and os.path.exists(shapefile_path):
                self.populate_shapefile_fields(shapefile_path, 'apca')
                self.append_console("Fields refreshed.")
            else:
                QMessageBox.warning(self, "No File", "Please select a shapefile first.")
        elif tab_name == 'afda':
            shapefile_path = self.shp_line_edit_afda.text()
            if shapefile_path and os.path.exists(shapefile_path):
                self.populate_shapefile_fields(shapefile_path, 'afda')
                self.append_console("Fields refreshed.")
            else:
                QMessageBox.warning(self, "No File", "Please select a shapefile first.")
        elif tab_name == 'overlap':
            shapefile_path = self.shp_line_edit_overlap.text()
            if shapefile_path and os.path.exists(shapefile_path):
                self.populate_shapefile_fields(shapefile_path, 'overlap')
                self.append_console("Fields refreshed.")
            else:
                QMessageBox.warning(self, "No File", "Please select a shapefile first.")
        elif tab_name == 'polygon':
            shapefile_path = self.shp_line_edit_polygon.text()
            if shapefile_path and os.path.exists(shapefile_path):
                self.populate_shapefile_fields(shapefile_path, 'polygon')
                self.append_console("Fields refreshed.")
            else:
                QMessageBox.warning(self, "No File", "Please select a shapefile first.")
        else:
            shapefile_path = self.shp_line_edit_point.text()
            if shapefile_path and os.path.exists(shapefile_path):
                self.populate_shapefile_fields(shapefile_path, 'point')
                self.append_console("Fields refreshed.")
            else:
                QMessageBox.warning(self, "No File", "Please select a shapefile first.")

    def select_output_folder(self, tab_name):
        """Select output folder"""
        folder_path = QFileDialog.getExistingDirectory(self, "Select Output Folder")
        if folder_path:
            if tab_name == 'apca':
                self.out_line_edit_apca.setText(folder_path)
                self.append_console(f"Selected Output Folder: {folder_path}")
            elif tab_name == 'afda':
                self.out_line_edit_afda.setText(folder_path)
                self.append_console(f"Selected Output Folder: {folder_path}")
            elif tab_name == 'lala':
                self.out_line_edit_lala.setText(folder_path)
                self.append_console(f"Selected Output Folder: {folder_path}")
            elif tab_name == 'overlap':
                self.out_line_edit_overlap.setText(folder_path)
                self.append_console(f"Selected Output Folder: {folder_path}")
            elif tab_name == 'polygon':
                self.out_line_edit_polygon.setText(folder_path)
                self.append_console(f"Selected Output Folder: {folder_path}")
            else:
                self.out_line_edit_point.setText(folder_path)
                self.append_console(f"Selected Output Folder: {folder_path}")

    def on_stop_clicked(self):
        """Handle stop button click"""
        if self.worker and self.worker.isRunning():
            reply = QMessageBox.question(
                self,
                "Stop Analysis",
                "Are you sure you want to stop the analysis?\n\nProgress will be lost.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No
            )

            if reply == QMessageBox.StandardButton.Yes:
                self.append_console("\n" + "="*50)
                self.append_console("STOPPING ANALYSIS...", "warning")
                self.append_console("Please wait for current operation to complete.", "warning")
                self.append_console("="*50)

                self.worker.cancel()
                self.stop_button.setEnabled(False)
                self.stop_button.setText("Stopping...")

    def reject(self):
        """Handle dialog close/cancel button"""
        if self.worker and self.worker.isRunning():
            reply = QMessageBox.question(
                self,
                "Analysis Running",
                "Analysis is still running. Do you want to stop it and close?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No
            )

            if reply == QMessageBox.StandardButton.Yes:
                self.append_console("Stopping analysis and closing dialog...", "warning")
                self.worker.cancel()

                if not self.worker.wait(3000):
                    self.append_console("Force terminating worker...", "error")
                    self.worker.terminate()
                    self.worker.wait(1000)

                self.worker = None
                super().reject()
            else:
                return
        else:
            super().reject()

    def closeEvent(self, event):
        """Handle window close button (X)"""
        if self.worker and self.worker.isRunning():
            reply = QMessageBox.question(
                self,
                "Analysis Running",
                "Analysis is still running. Do you want to stop it and close?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No
            )

            if reply == QMessageBox.StandardButton.Yes:
                self.append_console("Stopping analysis and closing...", "warning")
                self.worker.cancel()

                if not self.worker.wait(3000):
                    self.worker.terminate()
                    self.worker.wait(1000)

                self.worker = None
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()

    def analysis_finished(self, success, message):
        """Handle analysis completion"""
        self.run_button.setEnabled(True)
        self.run_button.setText("Run Analysis")
        self.cancel_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.stop_button.setText("Stop")
        self.progress_bar.setVisible(False)

        if success:
            self.progress_bar.setValue(100)
            self.append_console(f"\n✓ {message}", "info")
            QMessageBox.information(
                self,
                "Analysis Complete",
                message,
                QMessageBox.StandardButton.Ok
            )
        else:
            self.append_console(f"\n✗ {message}", "error")
            if "cancelled" not in message.lower():
                QMessageBox.critical(
                    self,
                    "Analysis Failed",
                    message,
                    QMessageBox.StandardButton.Ok
                )

    def clear_console(self):
        """Clear the console output"""
        self.console.clear()
        self.append_console("Console cleared.")

    def save_console(self):
        """Save console output to file"""
        file_path, _ = QFileDialog.getSaveFileName(
            self.dlg, "Save Console Output", "", "Text Files (*.txt);;All Files (*)"
        )
        if file_path:
            with open(file_path, 'w') as f:
                f.write(self.console.toPlainText())
            self.append_console(f"Console saved to: {file_path}")

    def get_parameters(self):
        """Get parameters from the active tab"""
        current_tab = self.tab_widget.currentIndex()

        if current_tab == 0:  # APCA
            nc_file = self.nc_line_edit_apca.text()
            shp_file = self.shp_line_edit_apca.text()
            output_folder = self.out_line_edit_apca.text()
            thk_var = self.thk_var_combo.currentText()

            id_field = self.id_field_combo.currentText()
            if id_field == "-- Do not group (analyze all together) --":
                id_field = None

            if not nc_file or not shp_file or not output_folder:
                QMessageBox.warning(self, "Missing Input", "Please select all input files and output folder.")
                return None

            if not os.path.exists(nc_file):
                QMessageBox.warning(self, "File Not Found", f"NetCDF file not found: {nc_file}")
                return None

            if not os.path.exists(shp_file):
                QMessageBox.warning(self, "File Not Found", f"Shapefile not found: {shp_file}")
                return None

            return {
                'analysis_type': 'apca',
                'nc_file': nc_file,
                'shp_file': shp_file,
                'output_folder': output_folder,
                'thk_var': thk_var,
                'id_field': id_field,
                'start_idx': self.start_spin_apca.value(),
                'end_idx': self.end_spin_apca.value(),
                'step': self.step_spin_apca.value(),
                'cell_size': self.cell_size_apca.value(),
                'ice_threshold': self.ice_threshold_apca.value(),
                'min_ice_thickness': self.min_thickness_apca.value(),
                'save_plots': self.save_plots_apca.isChecked(),
                'use_time_window': self.use_window_apca.isChecked(),
                'window_size': self.window_size_apca.value(),
                'use_accumulative_ice': self.accumulative_ice_apca.isChecked(),
                'save_shapefiles': self.save_shapefiles_apca.isChecked()
            }

        elif current_tab == 1:  # AFDA
            nc_file = self.nc_line_edit_afda.text()
            shp_file = self.shp_line_edit_afda.text()
            output_folder = self.out_line_edit_afda.text()
            u_var = self.u_var_combo.currentText()
            v_var = self.v_var_combo.currentText()
            ice_var = self.ice_var_combo.currentText()
            ice_type = self.ice_type_combo.currentText()

            if not nc_file or not shp_file or not output_folder:
                QMessageBox.warning(self, "Missing Input", "Please select all input files and output folder.")
                return None

            if not os.path.exists(nc_file):
                QMessageBox.warning(self, "File Not Found", f"NetCDF file not found: {nc_file}")
                return None

            if not os.path.exists(shp_file):
                QMessageBox.warning(self, "File Not Found", f"Shapefile not found: {shp_file}")
                return None

            return {
                'analysis_type': 'afda',
                'nc_file': nc_file,
                'shp_file': shp_file,
                'output_folder': output_folder,
                'u_var': u_var,
                'v_var': v_var,
                'ice_var': ice_var,
                'ice_type': ice_type,
                'start_idx': self.start_spin_afda.value(),
                'end_idx': self.end_spin_afda.value(),
                'step': self.step_spin_afda.value(),
                'cell_size': self.cell_size_afda.value(),
                'ice_threshold': self.ice_threshold_afda.value(),
                'velocity_threshold': self.velocity_threshold_afda.value(),
                'save_rasters': self.save_rasters_afda.isChecked(),
                'use_time_window': self.use_window_check.isChecked(),
                'window_size': self.window_size_spin.value(),
                'use_accumulative_ice': self.accumulative_ice_afda.isChecked()
            }
        elif current_tab == 2:  # LALA
            nc_file = self.nc_line_edit_lala.text()
            shp_file = self.shp_line_edit_lala.text()
            output_folder = self.out_line_edit_lala.text()
            u_var = self.u_var_combo.currentText()
            v_var = self.v_var_combo.currentText()
            thk_var = self.thk_var_combo.currentText()
            mask_var = self.mask_var_combo.currentText()

            if not nc_file or not shp_file or not output_folder:
                QMessageBox.warning(self, "Missing Input", "Please select all input files and output folder.")
                return None

            if not os.path.exists(nc_file):
                QMessageBox.warning(self, "File Not Found", f"NetCDF file not found: {nc_file}")
                return None

            if not os.path.exists(shp_file):
                QMessageBox.warning(self, "File Not Found", f"Shapefile not found: {shp_file}")
                return None

            return {
                'analysis_type': 'lala',
                'nc_file': nc_file,
                'shp_file': shp_file,
                'output_folder': output_folder,
                'u_var': u_var,
                'v_var': v_var,
                'thk_var': thk_var,
                'mask_var': mask_var,
                'thk_threshold': self.thk_threshold_lala.value(),
                'velocity_threshold': self.velocity_threshold_lala.value(),
                'grounded_ice': self.mask_threshold_combo_lala.currentText(),
                'kappa': self.kappa_spin_lala.value(),
                'p_value': self.p_value_lala.value()
            }

        elif current_tab == 3:  # Polygon-based Overlap
            nc_file = self.nc_line_edit_polygon.text()
            shp_file = self.shp_line_edit_polygon.text()
            output_folder = self.out_line_edit_polygon.text()
            thk_var = self.thk_var_combo_polygon.currentText()

            id_field = self.id_field_combo_polygon.currentText()
            if id_field == "-- Do not group (analyze all together) --":
                id_field = None

            if not nc_file or not shp_file or not output_folder:
                QMessageBox.warning(self, "Missing Input", "Please select all input files and output folder.")
                return None

            return {
                'analysis_type': 'polygon_overlap',
                'nc_file': nc_file,
                'shp_file': shp_file,
                'output_folder': output_folder,
                'thk_var': thk_var,
                'id_field': id_field,
                'start_idx': self.start_spin_polygon.value(),
                'end_idx': self.end_spin_polygon.value(),
                'step': self.step_spin_polygon.value(),
                'min_ice_thickness': self.min_thickness_polygon.value(),
                'min_polygon_area_km2': self.min_polygon_area.value(),
                'use_time_window': self.use_window_polygon.isChecked(),
                'window_size': self.window_size_polygon.value(),
                'use_accumulative_ice': self.accumulative_ice_polygon.isChecked(),
                'save_shapefiles': self.save_shapefiles_polygon.isChecked(),
                'save_plots': self.save_plots_polygon.isChecked()
            }

        elif current_tab == 4:  # point comparison
            nc_file = self.nc_line_edit_point.text()
            shp_file = self.shp_line_edit_point.text()
            output_folder = self.out_line_edit_point.text()
            var_name = self.var_combo_point.currentText()
            thickness_var = self.thick_var_combo_point.currentText()
            min_ice_thickness = self.min_thickness_point.value()

            value_field = self.value_field_combo_point.currentText()
            if value_field == "-- Select value field --":
                QMessageBox.warning(self, "Missing Selection", "Please select the observed value field.")
                return None

            id_field = self.id_field_combo_point.currentText()
            if id_field == "-- Do not group (analyze all together) --":
                id_field = None

            if not nc_file or not shp_file or not output_folder:
                QMessageBox.warning(self, "Missing Input", "Please select all input files and output folder.")
                return None

            return {
                'analysis_type': 'point_compare',
                'nc_file': nc_file,
                'shp_file': shp_file,
                'output_folder': output_folder,
                'var_name': var_name,
                'thickness_var': thickness_var,
                'min_ice_thickness': min_ice_thickness,
                'value_field': value_field,
                'id_field': id_field,
                'start_idx': self.start_spin_point.value(),
                'end_idx': self.end_spin_point.value(),
                'step': self.step_spin_point.value(),
                'use_time_window': self.use_window_point.isChecked(),
                'window_size': self.window_size_point.value(),
                'use_accumulative': self.accumulative_point.isChecked(),
                'save_plots': self.save_plots_point.isChecked()
            }
        elif current_tab == 5:  # raster to netcdf
            thick_folder = self.thick_folder_line_edit.text()
            if not thick_folder:
                QMessageBox.warning(self, "Missing Input", "Please select the thickness folder.")
                return None

            output_nc = self.output_nc_line_edit.text()
            if not output_nc:
                QMessageBox.warning(self, "Missing Input", "Please select output NetCDF file.")
                return None

            start_idx = self.convert_start_spin.value() if self.convert_start_spin.value() > 0 else None
            end_idx = self.convert_end_spin.value() if self.convert_end_spin.value() < 9999 else None
            step = self.convert_step_spin.value() if self.convert_step_spin.value() > 1 else None

            return {
                'analysis_type': 'raster_to_nc',
                'thick_folder': thick_folder,
                'surface_folder': self.surface_folder_line_edit.text() if self.surface_folder_line_edit.text() else None,
                'uvel_folder': self.uvel_folder_line_edit.text() if self.uvel_folder_line_edit.text() else None,
                'vvel_folder': self.vvel_folder_line_edit.text() if self.vvel_folder_line_edit.text() else None,
                'output_nc': output_nc,
                'start_idx': start_idx,
                'end_idx': end_idx,
                'step': step,
                'use_compression': self.use_compression.isChecked()
            }

        else:  # Overlap (unused tab)
            pass

    def on_run_clicked(self):
        """Handle run button click"""
        params = self.get_parameters()
        if not params:
            return

        self.run_button.setEnabled(False)
        self.run_button.setText("Running...")
        self.stop_button.setEnabled(True)
        self.stop_button.setText("Stop")
        self.cancel_button.setEnabled(False)

        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("Starting...")

        self.worker = AnalysisWorker(params['analysis_type'], params)

        # IMPORTANT: Use QueuedConnection so slots run on the GUI event loop
        # and do NOT re-enter while the worker is emitting. Combined with the
        # removal of QApplication.processEvents() in append_console /
        # update_progress, this eliminates the recursive signal-dispatch loop
        # that caused the "Windows fatal exception: stack overflow".
        self.worker.output_signal.connect(
            lambda tag, msg: self.append_console(msg, tag),
            Qt.ConnectionType.QueuedConnection,
        )
        self.worker.progress.connect(
            self.update_progress,
            Qt.ConnectionType.QueuedConnection,
        )
        self.worker.finished.connect(
            self.analysis_finished,
            Qt.ConnectionType.QueuedConnection,
        )

        self.worker.start()

    def update_progress(self, value, message):
        """Update progress bar (no re-entrant event pumping).

        WARNING: Do NOT call QApplication.processEvents() in this method.
        Same re-entrancy hazard as append_console.
        """
        if getattr(self, '_in_update_progress', False):
            return
        self._in_update_progress = True
        try:
            self.progress_bar.setValue(value)
            self.progress_bar.setFormat(f"{message} ({value}%)")
        finally:
            self._in_update_progress = False

    def analysis_finished_bak(self, success, message):
        """Handle analysis completion"""
        self.run_button.setEnabled(True)
        self.run_button.setText("Run Analysis")
        self.cancel_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.stop_button.setText("Stop")
        self.progress_bar.setVisible(False)

        if success:
            self.progress_bar.setValue(100)
            QMessageBox.information(self, "Analysis Complete", message)
        else:
            self.append_console(f"\nRESULT: {message}")
            if "cancelled" not in message.lower():
                QMessageBox.critical(self, "Analysis Failed", message)

    def update_end_time_from_netcdf(self, nc_file_path, tab_name):
        """Update the end time spin box based on NetCDF time dimension"""
        try:
            import xarray as xr
            ds = xr.open_dataset(nc_file_path, decode_times=False)
            total_times = len(ds.time)
            ds.close()

            if tab_name == 'apca':
                self.end_spin_apca.setMaximum(total_times - 1)
                self.end_spin_apca.setValue(total_times - 1)
                self.append_console(f"  NetCDF has {total_times} time steps. End time updated to {total_times - 1}.")
            elif tab_name == 'afda':
                self.end_spin_afda.setMaximum(total_times - 1)
                self.end_spin_afda.setValue(total_times - 1)
                self.append_console(f"  NetCDF has {total_times} time steps. End time updated to {total_times - 1}.")
            elif tab_name == 'overlap':
                self.end_spin_overlap.setMaximum(total_times - 1)
                self.end_spin_overlap.setValue(total_times - 1)
                self.append_console(f"  NetCDF has {total_times} time steps. End time updated to {total_times - 1}.")
            elif tab_name == 'polygon':
                self.end_spin_polygon.setMaximum(total_times - 1)
                self.end_spin_polygon.setValue(total_times - 1)
                self.append_console(f"  NetCDF has {total_times} time steps. End time updated to {total_times - 1}.")
            elif tab_name == 'point':
                self.end_spin_point.setMaximum(total_times - 1)
                self.end_spin_point.setValue(total_times - 1)
                self.append_console(f"  NetCDF has {total_times} time steps. End time updated to {total_times - 1}.")

        except Exception as e:
            self.append_console(f"  Warning: Could not read time dimension: {e}")

    def get_cpu_count(self):
        """Get the number of available CPU cores"""
        import multiprocessing
        try:
            cpu_count = multiprocessing.cpu_count()
            return max(1, cpu_count - 1)
        except:
            return 4

    def select_output_nc_file(self):
        """Select output NetCDF file"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save NetCDF File", "", "NetCDF Files (*.nc);;All Files (*)"
        )
        if file_path:
            if not file_path.endswith('.nc'):
                file_path += '.nc'
            self.output_nc_line_edit.setText(file_path)
            self.append_console(f"Output NetCDF file: {file_path}")

    def detect_time_range_from_folder(self, folder_path):
        """Auto-detect time range from files in folder"""
        try:
            import re
            from pathlib import Path

            extensions = ['.tif', '.tiff', '.asc']

            files = []
            for ext in extensions:
                files.extend(list(Path(folder_path).glob(f"*{ext}")))

            if not files:
                return

            times = []
            pattern = re.compile(r'(\d+)')
            for f in files:
                numbers = pattern.findall(f.stem)
                if numbers:
                    times.append(int(numbers[-1]))

            if times:
                times.sort()
                self.convert_start_spin.setValue(times[0])
                self.convert_end_spin.setValue(times[-1])
                self.append_console(f"  Detected time range: {times[0]} to {times[-1]} (total {len(times)} files)")
        except Exception as e:
            self.append_console(f"  Could not detect time range: {e}")

    def on_pattern_changed(self, text):
        """Handle file pattern selection change"""
        if text == "Custom":
            self.custom_pattern_edit.setVisible(True)
        else:
            self.custom_pattern_edit.setVisible(False)

    def on_crs_changed(self, text):
        """Handle CRS selection change"""
        if "Custom" in text:
            self.custom_crs_edit.setVisible(True)
        else:
            self.custom_crs_edit.setVisible(False)